#ifndef MYMATH_H
#define MYMATH_H

#include "includes.h"

class MYMATH
{
	public:
	static double getDir(VESSEL *v, double lat2, double lon2)
	{
		double tc1 = -1;
		double _lat1,_lon1,_rad1;
		v->GetEquPos(_lon1,_lat1,_rad1);
		double y = sin(lon2-_lon1)*cos(lat2);
		double x = cos(_lat1)*sin(lat2)-sin(_lat1)*cos(lat2)*cos(lon2-_lon1);
		if (y > 0)
		{
			if (x > 0) tc1 = atan(y/x);
			if (x < 0) tc1 = PI - atan(-y/x);
			if (x == 0) tc1 = PI/2;
		}
		if (y < 0)
		{
			if (x > 0)  tc1 = -atan(-y/x);
			if (x < 0)  tc1 = atan(y/x)-PI;
			if (x == 0) tc1 = PI*1.5;
		}
		if (y == 0)
		{
			if (x > 0) tc1 = 0;
			if (x < 0) tc1 = PI;
			if (x == 0) tc1 = 0;
		}
		double vh = 0;
		oapiGetFocusHeading(&vh);	
		if (tc1 < 0) tc1 = 2*PI + tc1;	
		tc1 = tc1 - vh;	
		if (tc1 < -PI) tc1 = 2*PI + tc1;
		return tc1;
	}

	static double getDirAbs(VESSEL *v, double lat2, double lon2)
	{
		double tc1 = -1;
		double _lat1,_lon1,_rad1;
		v->GetEquPos(_lon1,_lat1,_rad1);
		double y = sin(lon2-_lon1)*cos(lat2);
		double x = cos(_lat1)*sin(lat2)-sin(_lat1)*cos(lat2)*cos(lon2-_lon1);
		if (y > 0)
		{
			if (x > 0) tc1 = atan(y/x);
			if (x < 0) tc1 = PI - atan(-y/x);
			if (x == 0) tc1 = PI/2;
		}
		if (y < 0)
		{
			if (x > 0)  tc1 = -atan(-y/x);
			if (x < 0)  tc1 = atan(y/x)-PI;
			if (x == 0) tc1 = PI*1.5;
		}
		if (y == 0)
		{
			if (x > 0) tc1 = 0;
			if (x < 0) tc1 = PI;
			if (x == 0) tc1 = 0;
		}
		return tc1;
	}

	static double getDist(VESSEL* V, double l2, double b2)
	{
		double l1,b1,r1;
		V->GetEquPos(l1,b1,r1);
		if (l1 == l2 && b1 == b2) return 0;
		VESSELSTATUS vs;
		V->GetStatus(vs);
		OBJHANDLE rb = vs.rbody;
		double a = oapiGetSize(rb);
		double F = (b1+b2)/2;
		double G = (b1-b2)/2;
		double l = (l1-l2)/2;
		double S = (sin(G)*sin(G))*(cos(l)*cos(l)) + (cos(F)*cos(F))*(sin(l)*sin(l));
		double C = (cos(G)*cos(G))*(cos(l)*cos(l)) + (sin(F)*sin(F))*(sin(l)*sin(l));
		double w = atan(sqrt(S/C));
		double R = sqrt(S*C)/w;
		double D = 2*w*a;
		double H1 = (3*R-1)/(2*C);
		double H2 = (3*R+1)/(2*S);
		double f=0;
		double s = D*(1 + f*H1*(sin(F)*sin(F))*(cos(G)*cos(G)) - f*H2*(cos(F)*cos(F))*(sin(G)*sin(G)));
		return s;
	}

	static double getDist(VESSEL* V, double b1, double l1, double b2, double l2, OBJHANDLE rbody)
	{
		OBJHANDLE rb = 0;
		VESSELSTATUS vs;
		V->GetStatus(vs);
		if (rbody == 0) rb = vs.rbody;
		else rb = rbody;
		double a = oapiGetSize(rb);
		double F = (b1+b2)/2;
		double G = (b1-b2)/2;
		double l = (l1-l2)/2;
		double S = (sin(G)*sin(G))*(cos(l)*cos(l)) + (cos(F)*cos(F))*(sin(l)*sin(l));
		double C = (cos(G)*cos(G))*(cos(l)*cos(l)) + (sin(F)*sin(F))*(sin(l)*sin(l));
		double w = atan(sqrt(S/C));
		double R = sqrt(S*C)/w;
		double D = 2*w*a;
		double H1 = (3*R-1)/(2*C);
		double H2 = (3*R+1)/(2*S);
		double f=0;
		double s = D*(1 + f*H1*(sin(F)*sin(F))*(cos(G)*cos(G)) - f*H2*(cos(F)*cos(F))*(sin(G)*sin(G)));
		return s;
	}

	static double degToRad(double deg)
	{
		return (PI/180)*deg;
	}

	static MATRIX3 normalise(MATRIX3 m33)
	{
		VECTOR3 v1;
		v1.x = m33.m11;
		v1.y = m33.m12;
		v1.z = m33.m13;
		__ORBITERAPI_H::normalise(v1);
		VECTOR3 v2;
		v2.x = m33.m21;
		v2.y = m33.m22;
		v2.z = m33.m23;
		__ORBITERAPI_H::normalise(v2);
		VECTOR3 v3;
		v3.x = m33.m31;
		v3.y = m33.m32;
		v3.z = m33.m33;
		__ORBITERAPI_H::normalise(v3);
		m33.m11 = v1.x; m33.m12= v1.y; m33.m13 = v1.z;
		m33.m21 = v2.x; m33.m22= v2.y; m33.m23 = v2.z;
		m33.m31 = v3.x; m33.m32= v3.y; m33.m33 = v3.z;
		return m33;		
	}

	static MATRIX3 rotateMatrix(VECTOR3 vn, MATRIX3 m33, double alpha)
	{
		__ORBITERAPI_H::normalise(vn);
		double n1 = vn.x;
		double n2 = vn.y;
		double n3 = vn.z;		
		MATRIX3 matrix;

		double ca = (double) cos(alpha);
		double sa = (double) sin(alpha);		
		double emca = 1-ca;		
		double h1 = n1*emca; 
		double h2 = n2*emca;
		double h3 = n3*emca;		
		double n1s = n1*sa;
		double n2s = n2*sa;
		double n3s = n3*sa;
		
		matrix.m11 = n1*h1+ca;   matrix.m12 = n1*h2-n3s;   matrix.m13 = n1*h3+n2s;
		matrix.m21 = n2*h1+n3s;  matrix.m22 = n2*h2+ca;    matrix.m23 = n2*h3-n1s;
		matrix.m31 = n3*h1-n2s;  matrix.m32 = n3*h2+n1s;   matrix.m33 = n3*h3+ca;     
		m33 = normalise(m33);
		matrix = normalise(matrix);
		return mul((m33),(matrix));
	}

	static MATRIX3 getRotationMatrixFromHandle(OBJHANDLE object)
	{
		MATRIX3 m;
		oapiGetRotationMatrix(object,&m);
		return m;
	}
	template <size_t N,size_t M>
	
	static bool swapLine(double mat[N][M], size_t line1, size_t line2)
	{
		if(line1 >= N || line2 >= N)
			return false;
 
		for(size_t i = 0; i < M; ++i)
		{
			double t = mat[line1][i];
			mat[line1][i] = mat[line2][i];
			mat[line2][i] = t;
		}
     
		return true;
	}

	static double getVectorAngle(VECTOR3 v1, VECTOR3 v2)
	{
		double dot = v1.x*v2.x + v1.y*v2.y + v1.z*v2.z;
		double lenSq1 = v1.x*v1.x + v1.y*v1.y + v1.z*v1.z;
		double lenSq2 = v2.x*v2.x + v2.y*v2.y + v2.z*v2.z;
		double angle = acos(dot/sqrt(lenSq1 * lenSq2));
		return angle;
	}

	static MATRIX3 invertMatrix(MATRIX3 m3)
	{
		const int N = 3;
		double mat[N][N]; 
		double inv[N][N];
		MATRIX3 m3_inv;
		mat[0][0] = m3.m11;
		mat[0][1] = m3.m12;
		mat[0][2] = m3.m13;

		mat[1][0] = m3.m21;
		mat[1][1] = m3.m22;
		mat[1][2] = m3.m23;

		mat[2][0] = m3.m31;
		mat[2][1] = m3.m32;
		mat[2][2] = m3.m33;
	
			// Eine Nx2N Matrix f�r den Gau�-Jordan-Algorithmus aufbauen
		double A[N][2*N];
		for(size_t i = 0; i < N; ++i)
		{
			for(size_t j = 0; j < N; ++j)
				A[i][j] = mat[i][j];
			for(size_t j = N; j < 2*N; ++j)
				A[i][j] = (i==j-N) ? 1.0 : 0.0;
		}
 
		// Gau�-Algorithmus.
		for(size_t k = 0; k < N-1; ++k)
		{
			// Zeilen vertauschen, falls das Pivotelement eine Null ist
			if(A[k][k] == 0.0)
			{
				for(size_t i = k+1; i < N; ++i)
				{
					if(A[i][k] != 0.0)
					{
						swapLine<N, 2*N>(A,k,i);
						break;
					}
					else if(i==N-1)
						return m3; // Es gibt kein Element != 0
				}
			}
 
			// Eintr�ge unter dem Pivotelement eliminieren
			for(size_t i = k+1; i < N; ++i)
			{
				double p = A[i][k]/A[k][k];     
				for(size_t j = k; j < 2*N; ++j)
					A[i][j] -= A[k][j]*p;
			}
		}
 
		// Determinante der Matrix berechnen
		double det = 1.0;
		for(size_t k = 0; k < N; ++k)
			det *= A[k][k];
 
		if(det == 0.0)  // Determinante ist =0 -> Matrix nicht invertierbar
			return m3;
 
		// Jordan-Teil des Algorithmus durchf�hren
		for(size_t k = N-1; k > 0; --k)
		{
			for(int i = k-1; i >= 0; --i)
			{
				double p = A[i][k]/A[k][k];
				for(size_t j = k; j < 2*N; ++j)
					A[i][j] -= A[k][j]*p;
			}
		}
 
		// Eintr�ge in der linker Matrix auf 1 normieren und in inv schreiben
		for(size_t i = 0; i < N; ++i)
		{
			const double f = A[i][i];
			for(size_t j = N; j < 2*N; ++j)
				inv[i][j-N] = A[i][j]/f;
		}
 
		m3_inv.m11 = inv[0][0];
		m3_inv.m12 = inv[0][1];
		m3_inv.m13 = inv[0][2];

		m3_inv.m21 = inv[1][0];
		m3_inv.m22 = inv[1][1];
		m3_inv.m23 = inv[1][2];

		m3_inv.m31 = inv[2][0];
		m3_inv.m32 = inv[2][1];
		m3_inv.m33 = inv[2][2];

		return m3_inv;
	}
};
#endif