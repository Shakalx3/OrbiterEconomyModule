#ifndef BASICAUTOPILOT_H
#define BASICAUTOPILOT_H

#include "includes.h"

extern double dtPre;

class basicAutoPilot
{
	public:
		VESSEL *v;
		VECTOR3 thrust;
		VECTOR3 deltaAngularVelOld;
		basicAutoPilot(VESSEL *vessel)
		{
			//f = 1000;
			v = vessel;			
			
			const double kpp = 0.1;
			const double kip = 0;
			const double kdp = 0;

			VECTOR3 KPp = {kpp , kpp, kpp};
			VECTOR3 KIp = {kip , kip, kip};
			VECTOR3 KDp = {kdp , kdp, kdp};
		

			deltaAngularVelOld.x = 0;
			deltaAngularVelOld.y = 0;
			deltaAngularVelOld.z = 0;
			thrust.x = 0;
			thrust.y = 0;
			thrust.z = 0;

			//for (int i = 0; i < 1000; i++)
				//deltaSimTime[i] = 0;
		}
		/*
		bool setYPRSpeed(VECTOR3 YPRSpeedSetpoint, bool yaw, bool pitch, bool bank)
		{
			VECTOR3 v3_angularVel;
			v->GetAngularVel(v3_angularVel);  // X= Pitch  Y= Yaw  Z= Bank

			VECTOR3 deltaAngularVel;
			deltaAngularVel.x = (YPRSpeedSetpoint.x - v3_angularVel.y);  // x and y for VESSEL->GetPMI() (used byGet MaxAngAcc) and VESSEL->GetAngularVel are swapped
			deltaAngularVel.y = (YPRSpeedSetpoint.y - v3_angularVel.x);
			deltaAngularVel.z = (YPRSpeedSetpoint.z - v3_angularVel.z);
			
			VECTOR3 angularAccRequired;
			double f = 0.8;
			angularAccRequired.x = deltaAngularVel.x / oapiGetSimStep();
			angularAccRequired.y = deltaAngularVel.y / oapiGetSimStep();
			angularAccRequired.z = deltaAngularVel.z / oapiGetSimStep();

			//angularAccRequired.x = deltaAngularVel.x < 0 ? -angularAccRequired.x : angularAccRequired.x;
			//angularAccRequired.y = deltaAngularVel.y < 0 ? -angularAccRequired.y : angularAccRequired.y;
			//angularAccRequired.z = deltaAngularVel.z < 0 ? -angularAccRequired.z : angularAccRequired.z;

			VECTOR3 maxAngularAcc = ORBITERTOOLS::GetMaxAngAcc(v);  //Returns the maxumum angular acceleration in �/s�			
			VECTOR3 thrust;

			thrust.x = ((angularAccRequired.x) / (maxAngularAcc.y));	//Calculating the "percentage thrust" for the thruster groups.
			thrust.y = ((angularAccRequired.y) / (maxAngularAcc.x));	// x and y for VESSEL->GetPMI() (used byGet MaxAngAcc) and VESSEL->GetAngularVel are swapped
			thrust.z = ((angularAccRequired.z) / (maxAngularAcc.z));

			if (yaw)
			{
				v->SetThrusterGroupLevel(THGROUP_ATT_YAWLEFT, thrust.x);
				v->SetThrusterGroupLevel(THGROUP_ATT_YAWRIGHT, -thrust.x);
			}
			if (pitch)
			{
				v->SetThrusterGroupLevel(THGROUP_ATT_PITCHUP, thrust.y);
				v->SetThrusterGroupLevel(THGROUP_ATT_PITCHDOWN, -thrust.y);
			}
			if (bank)
			{
				v->SetThrusterGroupLevel(THGROUP_ATT_BANKRIGHT, thrust.z);
				v->SetThrusterGroupLevel(THGROUP_ATT_BANKLEFT, -thrust.z);
			}
			return true;
		}
		*/
		bool setYPRSpeedTest(VECTOR3 YPRSpeedSetpoint, bool yaw, bool pitch, bool bank)
		{
			VECTOR3 v3_angularVel;
			v->GetAngularVel(v3_angularVel);  // X= Pitch  Y= Yaw  Z= Bank
			
			VECTOR3 deltaAngularVel;
			deltaAngularVel.x = (YPRSpeedSetpoint.x - v3_angularVel.x);  // x and y for VESSEL->GetPMI() (used byGet MaxAngAcc) and VESSEL->GetAngularVel are swapped
			deltaAngularVel.y = (YPRSpeedSetpoint.y - v3_angularVel.y);
			deltaAngularVel.z = (YPRSpeedSetpoint.z - v3_angularVel.z);
			
			const double f0 = 1;
			const double f1 = 15;
			thrust.x = log(1 + fabs(deltaAngularVel.x) * f0) * f1; 
			thrust.y = log(1 + fabs(deltaAngularVel.y) * f0) * f1;
			thrust.z = log(1 + fabs(deltaAngularVel.z) * f0) * f1;

			thrust.x *= fabs(deltaAngularVel.x) / deltaAngularVel.x;
			thrust.y *= fabs(deltaAngularVel.y) / deltaAngularVel.y;
			thrust.z *= fabs(deltaAngularVel.z) / deltaAngularVel.z;

			if (thrust.x > 1) thrust.x = 1; if (thrust.x < -1) thrust.x = -1;
			if (thrust.y > 1) thrust.y = 1; if (thrust.y < -1) thrust.y = -1;
			if (thrust.z > 1) thrust.z = 1; if (thrust.z < -1) thrust.z = -1;
			
			if (thrust.x != thrust.x || thrust.y != thrust.y || thrust.z != thrust.z) return false;
			if (pitch)
			{
				v->SetThrusterGroupLevel(THGROUP_ATT_PITCHUP, thrust.x);
				v->SetThrusterGroupLevel(THGROUP_ATT_PITCHDOWN, -thrust.x);
			}
			if (yaw)
			{
				v->SetThrusterGroupLevel(THGROUP_ATT_YAWLEFT, thrust.y);
				v->SetThrusterGroupLevel(THGROUP_ATT_YAWRIGHT, -thrust.y);
			}
			if (bank)
			{
				v->SetThrusterGroupLevel(THGROUP_ATT_BANKRIGHT, thrust.z);
				v->SetThrusterGroupLevel(THGROUP_ATT_BANKLEFT, -thrust.z);
			}
			deltaAngularVelOld = deltaAngularVel;
			return true;
		}


		
		bool setYPRSpeed(VECTOR3 YPRSpeedSetpoint, bool yaw, bool pitch, bool bank)
		{
			VECTOR3 v3_angularVel;
			v->GetAngularVel(v3_angularVel);  // X= Pitch  Y= Yaw  Z= Bank
			VECTOR3 deltaAngularVel;

			deltaAngularVel.x = (YPRSpeedSetpoint.x - v3_angularVel.x);  // x and y for VESSEL->GetPMI() (used byGet MaxAngAcc) and VESSEL->GetAngularVel are swapped
			deltaAngularVel.y = (YPRSpeedSetpoint.y - v3_angularVel.y);
			deltaAngularVel.z = (YPRSpeedSetpoint.z - v3_angularVel.z);

			/*
			const double rampVal = 0.001;
			const double frampVal = 1/ rampVal;
			if (fabs(deltaAngularVel.x) < rampVal) deltaAngularVel.x *= frampVal * fabs(deltaAngularVel.x);
			if (fabs(deltaAngularVel.y) < rampVal) deltaAngularVel.y *= frampVal * fabs(deltaAngularVel.y);
			if (fabs(deltaAngularVel.z) < rampVal) deltaAngularVel.z *= frampVal * fabs(deltaAngularVel.z);
			*/

			VECTOR3 deltaDeltaAngularVel = (deltaAngularVel - deltaAngularVelOld);
			VECTOR3 angularAccRequired = ((deltaAngularVel + deltaDeltaAngularVel)*0.45) / dtPre;

			const double f = 1;
			angularAccRequired.x = angularAccRequired.x * log(1 + fabs(angularAccRequired.x * f));
			angularAccRequired.y = angularAccRequired.y * log(1 + fabs(angularAccRequired.y * f));
			angularAccRequired.z = angularAccRequired.z * log(1 + fabs(angularAccRequired.z * f));
					
			VECTOR3 maxAngularAcc = ORBITERTOOLS::GetMaxAngAcc(v);  //Returns the maxumum angular acceleration in �/s�			
			VECTOR3 thrust;
			thrust.x = ((angularAccRequired.x) / (maxAngularAcc.x));	//Calculating the "percentage thrust" for the thruster groups.
			thrust.y = ((angularAccRequired.y) / (maxAngularAcc.y));	// x and y for VESSEL->GetPMI() (used byGet MaxAngAcc) and VESSEL->GetAngularVel are swapped
			thrust.z = ((angularAccRequired.z) / (maxAngularAcc.z));

			//sprintf(oapiDebugString(), "%f\n%f\n%f", thrust.x, angularAccRequired.x, deltaDeltaAngularVel.x);
			//On a NAN exception, var == var is false.
			// However, this should not occur anymore...
			//thrust /= log(oapiGetTimeAcceleration()) + 1;
			
			/*
			const double rampVal2 = 0.01;
			const double frampVal2 = 1 / rampVal2;
			if (fabs(deltaAngularVel.x) < rampVal2) thrust.x *= frampVal2 * fabs(thrust.x);
			if (fabs(deltaAngularVel.y) < rampVal2) thrust.y *= frampVal2 * fabs(thrust.y);
			if (fabs(deltaAngularVel.z) < rampVal2) thrust.z *= frampVal2 * fabs(thrust.z);
			*/
			/*
			thrust.x *= 0.25;
			thrust.y *= 0.25;
			thrust.z *= 0.25;
			*/
			if (thrust.x != thrust.x || thrust.y != thrust.y || thrust.z != thrust.z) return false;
			if (pitch)
			{
				v->SetThrusterGroupLevel(THGROUP_ATT_PITCHUP, thrust.x);
				v->SetThrusterGroupLevel(THGROUP_ATT_PITCHDOWN, -thrust.x);
			}
			if (yaw)
			{
				v->SetThrusterGroupLevel(THGROUP_ATT_YAWLEFT, thrust.y);
				v->SetThrusterGroupLevel(THGROUP_ATT_YAWRIGHT, -thrust.y);
			}
			if (bank)
			{
				v->SetThrusterGroupLevel(THGROUP_ATT_BANKRIGHT, thrust.z);
				v->SetThrusterGroupLevel(THGROUP_ATT_BANKLEFT, -thrust.z);
			}
			deltaAngularVelOld = deltaAngularVel;
			return true;
		}

		/*
		bool setYPRSpeed2(VECTOR3 YPRSpeedSetpoint, bool yaw, bool pitch, bool bank)
		{

			VECTOR3 v3_angularVel;
			v->GetAngularVel(v3_angularVel);  // X= Pitch  Y= Yaw  Z= Bank
			VECTOR3 deltaAngularVel;
	
			deltaAngularVel.x = (YPRSpeedSetpoint.x - v3_angularVel.x);  // x and y for VESSEL->GetPMI() (used byGet MaxAngAcc) and VESSEL->GetAngularVel are swapped
			deltaAngularVel.y = (YPRSpeedSetpoint.y - v3_angularVel.y);
			deltaAngularVel.z = (YPRSpeedSetpoint.z - v3_angularVel.z);
			
			VECTOR3 i;

			i.x = deltaAngularVel.x < 0 ? -1 : 1;
			i.y = deltaAngularVel.y < 0 ? -1 : 1;
			i.z = deltaAngularVel.z < 0 ? -1 : 1;

			//Returns the maximum possible angular acceleration in �/s�			
			VECTOR3 maxAngularAcc = ORBITERTOOLS::GetMaxAngAcc(v);
			VECTOR3 thrust;

			VECTOR3 angularAccRequired;						
			angularAccRequired.x = deltaAngularVel.x / dtPre;
			angularAccRequired.y = deltaAngularVel.y / dtPre;
			angularAccRequired.z = deltaAngularVel.z / dtPre;
			


			thrust.x = ((angularAccRequired.x) / (maxAngularAcc.x));
			thrust.y = ((angularAccRequired.y) / (maxAngularAcc.y));
			thrust.z = ((angularAccRequired.z) / (maxAngularAcc.z));

			//On a NAN exception, var == var is false.
			// However, this should not occur anymore...
			if (thrust.x != thrust.x || thrust.y != thrust.y || thrust.z != thrust.z) return false;
			if (pitch)
			{
				v->SetThrusterGroupLevel(THGROUP_ATT_PITCHUP, thrust.x);
				v->SetThrusterGroupLevel(THGROUP_ATT_PITCHDOWN, -thrust.x);
			}
			if (yaw)
			{
				v->SetThrusterGroupLevel(THGROUP_ATT_YAWLEFT, thrust.y);
				v->SetThrusterGroupLevel(THGROUP_ATT_YAWRIGHT, -thrust.y);
			}
			if (bank)
			{
				v->SetThrusterGroupLevel(THGROUP_ATT_BANKRIGHT, thrust.z);
				v->SetThrusterGroupLevel(THGROUP_ATT_BANKLEFT, -thrust.z);
			}
			deltaAngularVelOld = deltaAngularVel;
			return true;
		}
		*/
		void resetThruster2()
		{					
			v->SetThrusterGroupLevel(THGROUP_ATT_YAWLEFT,0);
			v->SetThrusterGroupLevel(THGROUP_ATT_YAWRIGHT,0);
			v->SetThrusterGroupLevel(THGROUP_ATT_PITCHDOWN,0);
			v->SetThrusterGroupLevel(THGROUP_ATT_PITCHUP,0);
			v->SetThrusterGroupLevel(THGROUP_ATT_BANKRIGHT,0);
			v->SetThrusterGroupLevel(THGROUP_ATT_BANKLEFT,0);
		}	

		double getMaxVerticalThrGroupAcceleration(THGROUP_TYPE thg)
		{
			return v->GetMass() > 0 ? getMaxThrGroupForce(thg) / v->GetMass() : 0;
		}

		double getMaxThrGroupForce(THGROUP_TYPE thgt)
		{
			double force = 0;
			for(unsigned int i=0; i<v->GetGroupThrusterCount(thgt); i++) 
			{						
				THRUSTER_HANDLE th=v->GetGroupThruster(thgt,i);					
				force = force + v->GetThrusterMax(th);		
			}		
			return force * length(ORBITERTOOLS::getThrGroupDir(v, thgt));			
		}

		VECTOR3 getThrGroupForce(THGROUP_TYPE thgt)
		{
			return ORBITERTOOLS::getThrGroupDir(v,thgt) * v->GetThrusterGroupLevel(thgt) * getMaxThrGroupForce(thgt);
		}

		VECTOR3 getThrusterGroupTypeForceVector(THGROUP_TYPE thgt)
		{
			VECTOR3 totalEngineForce = {0,0,0};
			for(unsigned int i=0; i<v->GetGroupThrusterCount(thgt); i++) 
			{						
				THRUSTER_HANDLE th=v->GetGroupThruster(thgt,i);			
				VECTOR3 dir;
				v->GetThrusterDir(th,dir);
				double currentForce = v->GetThrusterMax(th) * v->GetThrusterLevel(th);
				totalEngineForce = totalEngineForce + (dir * currentForce);
			}
			return totalEngineForce;
		}

		double getThrustForVerticalAcceleration(double acceleration,THGROUP_TYPE thgt)
		{
			double max_acceleration = getMaxVerticalThrGroupAcceleration(thgt);
			VECTOR3 totalForce, thrustv;
			v->GetForceVector(totalForce);
			thrustv = getThrusterGroupTypeForceVector(thgt);
			totalForce = totalForce - thrustv ;			
			VECTOR3 v3_spd;			
			double x, y, r;
			v->GetEquPos(x,y,r);
			v->GetHorizonAirspeedVector(v3_spd);
			v->GetAirspeedVector(FRAME_REFLOCAL,v3_spd);

			double lng, lat, r2;
			v->GetEquPos(lng,lat,r2);
			VECTOR3 vgv = oapiGetGroundVector(v->GetGravityRef(),lng,lat);
			v3_spd += vgv;
			double vhsqr = (v3_spd.x * v3_spd.x) + (v3_spd.z * v3_spd.z);
			double fz = (v->GetMass() * vhsqr) / r;		
			double dweight = sqrt((totalForce.x * totalForce.x) + (totalForce.y * totalForce.y) +  (totalForce.z * totalForce.z));			
			double thrust = max_acceleration != 0 && v->GetMass() != 0 ? -(((dweight / v->GetMass()) - (-acceleration + (fz/ v->GetMass()) )) / max_acceleration) : 0;
			thrust = thrust / (ORBITERTOOLS::getEngineVectorDownward(v, thgt));
			return thrust;
		}

		void setVerticalACCByThrusterGroup(double acceleration,THGROUP_TYPE thgt)
		{			
			double th = getThrustForVerticalAcceleration(acceleration, thgt);
			v->SetThrusterGroupLevel(thgt,th);
		}

		double getAccelerationForVerticalSpeed(VESSEL *v, double speedSet)
		{
			VECTOR3 verticalSpeedCurrent;
			v->GetAirspeedVector(FRAME_LOCAL,verticalSpeedCurrent);
			return (speedSet-verticalSpeedCurrent.y) * 0.5;
		}


		double getThrustForHorizontalAcceleration(double acceleration,THGROUP_TYPE thgt)
		{
			double max_acceleration = getMaxVerticalThrGroupAcceleration(thgt);
			
			//double max_acceleration = getMaxTotalThrGroupAcceleration(thgt);
			
			double thrust = acceleration  / max_acceleration;
			thrust = thrust / (ORBITERTOOLS::getEngineVectorForward(v, thgt));
			return thrust/2;
		}

		void setHorizontalACCByThrusterGroup(double acceleration,THGROUP_TYPE thgt)
		{
			//double max_acceleration = getMaxVerticalThrGroupAcceleration(thgt);			
			v->SetThrusterGroupLevel(thgt,getThrustForHorizontalAcceleration(acceleration,thgt));
		}

		//*NEW
		double getMaxVerticalAcceleration(VESSEL *v, THGROUP_TYPE thgt, double bank, double pitch, double level=1)
		{
			double max_acceleration = getMaxVerticalThrGroupAcceleration(thgt);
			VECTOR3 totalForce, thrustv;
			v->GetForceVector(totalForce);
			v->GetThrustVector(thrustv);
			totalForce = totalForce - thrustv ;			
			VECTOR3 v3_spd;			
			double x, y, r;
			v->GetEquPos(x,y,r);
			v->GetAirspeedVector(FRAME_REFLOCAL,v3_spd);
			double lng, lat, r2;
			v->GetEquPos(lng,lat,r2);
			VECTOR3 vgv = oapiGetGroundVector(v->GetGravityRef(),lng,lat);
			v3_spd += vgv;
			double vhsqr = (v3_spd.x * v3_spd.x) + (v3_spd.z * v3_spd.z);
			double fz = (v->GetMass() * vhsqr) / r;		
			double dweight = sqrt((totalForce.x * totalForce.x) + (totalForce.y * totalForce.y) +  (totalForce.z * totalForce.z));			
			double aTotal = v->GetMass() > 0 ? (dweight - fz) / v->GetMass() : 0;
			return (max_acceleration * cos(bank)) - aTotal;
		}

		//*NEW	
		double getPitchForVerticalAcceleration(VESSEL *v, THGROUP_TYPE thgt, double bank, double setPoint, double level=0)
		{			
			double max_acceleration = getMaxVerticalThrGroupAcceleration(thgt);
			VECTOR3 totalForce, thrustv;
			v->GetForceVector(totalForce);
			v->GetThrustVector(thrustv);
			totalForce = totalForce - thrustv ;			
			VECTOR3 v3_spd;			
			double x, y, r;
			v->GetEquPos(x,y,r);
			v->GetAirspeedVector(FRAME_REFLOCAL,v3_spd);
			double lng, lat, r2;
			v->GetEquPos(lng,lat,r2);
			VECTOR3 vgv = oapiGetGroundVector(v->GetGravityRef(),lng,lat);
			v3_spd += vgv;
			double vhsqr = (v3_spd.x * v3_spd.x) + (v3_spd.z * v3_spd.z);
			double fz = (v->GetMass() * vhsqr) / r;		
			double dweight = sqrt((totalForce.x * totalForce.x) + (totalForce.y * totalForce.y) +  (totalForce.z * totalForce.z));					
			double fDownTotal = (dweight - fz);
			if (level == 0) level = v->GetThrusterGroupLevel(thgt);
			VECTOR3 f, ft;			
			v->GetForceVector(f);
			v->GetThrustVector(ft);
			double forceTotal = length(ft);
			setPoint *= v->GetMass();
			if (forceTotal <= (fDownTotal+setPoint)) return 0;
			if (bank == 1) return 0;
			double aTotal = (forceTotal * cos(bank)) != 0 ? acos(((fDownTotal+setPoint))/(forceTotal * cos(bank))) : 0;
			return aTotal;
		}
		/*
		double getAGrav(VESSEL *v, double speed, double r)
		{
			const double rGrav = oapiGetSize(v->GetGravityRef());
			double lng, lat, ra;
			v->GetEquPos(lng, lat, ra);
			const double m1 = v->GetMass();
			const double fz = (m1 * speed *speed) / r; //Zenrifugalkraft			
			double ag;
			for (int i = 0; i < oapiGetGbodyCount(); i++)
			{
				OBJHANDLE gBody = oapiGetGbodyByIndex(i);
				VECTOR3 dist;
				const double m2 = oapiGetMass(v->GetGravityRef());
				oapiGetRelativePos(v->GetHandle(), gBody, &dist);
				double rgbody = length2(dist);
				const double r2 = rgbody * rgbody;
				ag += GGRAV * m2 / r2;
				const double fg = ag * m1;
			}

			const double az = fz / m1;
			const double a = ag - az;
			//if (print) sprintf(oapiDebugString(), "%f %f %f", -a, ag, az);
			return -a;
		}
		*/
		double getAGrav(VESSEL *v, double speed, double r, bool print)
		{	
			const double rGrav = oapiGetSize(v->GetGravityRef());			
			double lng, lat, ra;
			v->GetEquPos(lng, lat,ra);
			const double m1 = v->GetMass();
			const double m2 = oapiGetMass(v->GetGravityRef());
			const double r2 = r * r;
			const double fz = (m1 * speed *speed) / r; //Zenrifugalkraft			
			const double ag = GGRAV * m2 / r2;
			const double fg = ag * m1;
			const double az = fz / m1;
			const double a = ag - az;
			//if (print) sprintf(oapiDebugString(), "%f %f %f", -a, ag, az);
			return -a;
		}

		double getAGrav(VESSEL *v)
		{
			//double max_acceleration = getMaxVerticalThrGroupAcceleration(thgt);
			VECTOR3 totalForce, thrustv;
			v->GetForceVector(totalForce);
			v->GetThrustVector(thrustv);
			totalForce = totalForce - thrustv;
			VECTOR3 v3_spd;
			double lng, lat, r;
			v->GetEquPos(lng, lat, r);
			v->GetAirspeedVector(FRAME_REFLOCAL, v3_spd);
			//double lng, lat, r2;
			//v->GetEquPos(lng,lat,r2);			
			VECTOR3 vgv = oapiGetGroundVector(v->GetGravityRef(), lng, lat);
			v3_spd += vgv;
			double vhsqr = (v3_spd.x * v3_spd.x) + (v3_spd.z * v3_spd.z);
			double fz = (v->GetMass() * vhsqr) / r;
			double dweight = sqrt((totalForce.x * totalForce.x) + (totalForce.y * totalForce.y) + (totalForce.z * totalForce.z));
			double aTotal = (dweight - fz) / v->GetMass();
			return aTotal;
		}

		double getThrustLevelForAcceleration(double acceleration,THGROUP_TYPE thgt)
		{
			double max_acceleration = getMaxVerticalThrGroupAcceleration(thgt);			
			double thrust = acceleration  / max_acceleration;
			thrust = ORBITERTOOLS::getEngineVectorDownward(v, thgt) != 0 ? thrust / (ORBITERTOOLS::getEngineVectorDownward(v, thgt)) : 0;
			return thrust;
		}

		double getThrustLevelForAcceleration2(double acceleration,THGROUP_TYPE thgt)
		{
			double max_acceleration = getMaxVerticalThrGroupAcceleration(thgt);			
			double thrust = max_acceleration != 0 ? acceleration  / max_acceleration : 0;
			thrust = thrust;
			return thrust;
		}

		double getMaxTotalThrGroupAcceleration(THGROUP_TYPE thgt)
		{
			double force = 0;
			for(unsigned int i=0; i<v->GetGroupThrusterCount(thgt); i++) 
			{						
				THRUSTER_HANDLE th=v->GetGroupThruster(thgt,i);					
				force = force + v->GetThrusterMax(th);		
			}		
			double maxa = 0;
			return force / v->GetMass();
		}

		bool setPitchAndEngineLevelForAccelerations(double aHSetpoint, double aVSetpoint, THGROUP_TYPE thgt,  double &pitch, double &level)
		{			

			VECTOR3 thgrpDir = ORBITERTOOLS::getThrGroupDir(v, thgt);
			double alpha = atan2(thgrpDir.y, thgrpDir.z);
			double maxa = getMaxTotalThrGroupAcceleration(thgt);
			double aGrav = getAGrav(v);
			if (aVSetpoint < -aGrav) aVSetpoint = -aGrav;
			double aVTotal = -aVSetpoint - aGrav;
			double *ptrPitch;
			ptrPitch = &pitch;
			double *ptrLevel;
			ptrLevel = &level;						
			double aTotal = sqrt((aHSetpoint*aHSetpoint)+(aVTotal*aVTotal));
			if (aTotal > maxa) aTotal = maxa;
			if (aTotal > 0) 
			{
				if (abs(aHSetpoint / aTotal) <= 1)
				{
					*ptrPitch = -asin(aHSetpoint / aTotal) - alpha + PI05;
				}
				else
				{
					*ptrPitch = 0; //ERROR!!!
					*ptrLevel = 0;
					return false;
				}
			}
			else 
			{
				*ptrPitch = PI05;
			}
			if (maxa != 0) 
				*ptrLevel = aTotal / maxa;
			else *ptrLevel = 0;
			return true;
		}
		/*
		void autopilottools::setACCByThrusterGroup(double acceleration,THGROUP_TYPE thgt)
		{
			double max_acceleration = getMaxThrGroupAcceleration(thgt);
			max_acceleration = max_acceleration * -getEngineAngle(thgt);	
			double thrust = (getVirtualACC(thgt)-acceleration) / max_acceleration;
			V->SetThrusterGroupLevel(thgt,thrust);
		}
		*/
};
#endif