#ifndef INCLUDES_H
#define INCLUDES_H

#include "GraphicsAPI.h"
#include "orbitersdk.h"
#include "CelBodyAPI.h"
#include <string>
#include <sstream>
#include <math.h>
#include <iomanip>
#include <vector>

#include "PidController.h"
#include "mymath.h"
#include "orbiterTools.h"
#include "quaternion.h"
//#include "pidCtrl.h"
#include "basicAutoPilot.h"
#include "autopilot.h"
#include "baseland_mfd.h"

//efine MFDMAXLINES 20

#endif