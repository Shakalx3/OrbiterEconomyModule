﻿#ifndef AUTOPILOT_MFD_H
#define AUTOPILOT_MFD_H

#include "includes.h"
class mfd_data
{
public:
	~mfd_data()
	{
		delete zoomList;
	}	
	OBJHANDLE hvessel;
	VESSEL* vessel;	
	static const int modecount = 4;
	static const int programcount = 3;
	mfd_data(OBJHANDLE hvessel);
	void resetSelection();
	int isGoForLand();
	int isGoForLand(NAVHANDLE nh);

	int getModeCount();
	int getMainProgramCount();
	enum landPermissions
	{
		LANDING_GO,
		LANDING_NO_GO,
		LANDING_NO_INFORMATION,
		LANDING_GO_WARNING
	};
	enum targetMode
	{
		NO_TARGET,
		BASE,
		NAVSOURCE,
		MANUAL
	};	
	enum mainProgramMode
	{
		PROGRAM_400_HOVER,
		PROGRAM_600_RETRO,
		PROGRAM_650_PRO,
	};
	std::string targetModes[modecount];
	std::string mainProgramModes[programcount];
	int currentTargetMode = NO_TARGET;
	int currentMainProgramMode = PROGRAM_400_HOVER;
	enum cursorLine
	{
		LINE1,
		LINE15,
		LINE2,		
		LINE3
	};
	int getMaxLines(int tm);
	void incMainProgram();
	void decMainProgram();
	void updateMainProgram();
	void incItem();
	void decItem();
	void incBase();
	void incNavSourceBase();
	void decNavSourceBase();
	void incNavSourcePad();
	void decNavSourcePad();
	void updateBaseDataFromNavReciever(NAVHANDLE nh);
	void decBase();
	void incLine();
	void decLine();
	void incBasePad();
	void decBasePad();
	void updateLngLat();
	int currentCursorLine;
	int currentNavSourceBase;
	int currentNavSourcePad;
	int currentBaseIndex;
	int currentBasePadIndex;
	int menuemode;

	const int nZoomLvl = 12; // Count of zoom levels
	const double *zoomList = new const double[nZoomLvl] {100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000}; // available zoom levels
	unsigned int zoomPtr = 8; // Array pointer to initial zoom level

	double totalDistanceZoom = zoomList[zoomPtr];
	double totalAltZoom = zoomList[zoomPtr];

};

class autopilot : public basicAutoPilot
{
	public:
		autopilot(VESSEL *vessel)  :  basicAutoPilot(vessel)
		{
			// Switch to the the hover thgroup on init			
			ptrProgram = 400;
			used_thgroup = THGROUP_HOVER;

			v = vessel;
			ypr_setpoint.x = 0;
			ypr_setpoint.y = 0;
			ypr_setpoint.z = 0;
			engineLevel = 0;

			masterChannel = false;
			yawChannel = false;
			pitchChannel = false;
			rollChannel = false;
			vaChannel = false;
			thrusterResetet = false;

			deltaPos.x = 0;
			deltaPos.y = 0;
			deltaPos.z = 0;

			baseElevation = 0;
			updateFlag = 500;

			ypr_setpoint.x = 0;
			ypr_setpoint.y = 0;
			ypr_setpoint.z = 0;

			currentYPR.x = 0;
			currentYPR.y = 0;
			currentYPR.z = 0;

			horizonAirspeedVector.x = 0;
			horizonAirspeedVector.y = 0;
			horizonAirspeedVector.z = 0;

			maxElevation = 0;
			distanceToMaxElevation = 0;
			
			inteceptAlt = 75;
			interceptPoint = 600;
			preHold = 1.618;  //Goldener Schnitt??
			//preHold = PI05;

			targetPoint.x = 0;
			targetPoint.y = 0;
			targetPoint.z = 0;
			scanRangeEndLast = 0;
			
			dv.x = 0;		
			dv.y = 0;
			dv.z = 0;

			dvOld.x = 0;
			dvOld.y = 0;
			dvOld.z = 0;

			menue_data = new mfd_data(vessel->GetHandle());
		}
		

		~autopilot();

		MATRIX3 mq;
		MATRIX3 v_matrix;
		MATRIX3 dm;

		MATRIX3 mq2;
		MATRIX3 v_matrix2;
		MATRIX3 dm2;
		VECTOR3 dv2;

		THGROUP_TYPE used_thgroup = THGROUP_HOVER;
		void maincontroll();		
		bool masterChannel; //Indicates if autopilot is on
		bool yawChannel;
		bool pitchChannel;
		bool rollChannel;
		bool vaChannel;
		double touchDownTime = -1;
		VECTOR3 ypr_setpoint; // Vectror of setpoints for yaw, pitch and roll
		double engineLevel;
		VESSEL * getVessel()
		{
			return v;
		}
		VECTOR3 dv; //Delta value between current value and set point for YPR
		double distanceToBasePad;
		VECTOR3 targetPoint;		
		double altOverGround;
		double baseElevation;
		double maxElevation;
		void resetThruster();
		double distanceToInterceptPont;
		double inteceptAlt;
		int ptrProgram;
		VESSEL *v;
		double getGearAlt(VESSEL* vessel);
		mfd_data *menue_data;
		VECTOR3 currentYPR;
		double terrainScanPtr = 0;
		double terrainAltAtPtr = 0;
		double distanceToMaxEvaluationCurrentScan = 0;
		double distanceToMaxElevation = 0;
		double distanceToMaxElevationFromBase = 0;
		double maxElevationCurrentScan = 0;
		double HorizontalSpeed;
		bool closingBase = false;
		VECTOR3 a_groundspeed;
		VECTOR3 deltaPos;
		double rAltMaxElevation;
		double dt_maxElevation;
		double rAltBase;
		double getDtForDistance(double distance);
	private:
		double verticalSpeedOld;
		double distanceToBasePadOld = 0;
		bool thrusterResetet;
		bool masterChannel_last;
		double iPitch, iBank, iYaw;
		void ctrlYPR();
		bool GetOffsetToBase();
		
		void updateData();
		void setProgram(int ptrProgram);
		//Hoverengine Programs
		void program400(); //Wait for acceleration (No braking), no RCS, no RADAR
		void program405(); //Wait for acceleration (No braking) RCS and RADAR
		void program410(); //Decent and brake program (Hover Engine Mode)	
		void program420(); //Rotate to near horizontal attitude		
		
		//Mainengine Programs
		void program600(); //Wait for acceleration (No braking), no RCS, no RADAR for Main Engine
		void program605(); //Wait for acceleration (No braking) RCS and RADAR for Main Engine 
		void program610();

		//Retroengine Programs
		void program650(); //Wait for acceleration (No braking), no RCS, no RADAR for Retro Engine
		void program655(); //Wait for acceleration (No braking) RCS and RADAR for Retro Engine
		void program660(); //Decent and brake program (Retro Engine Mode)

		// Common touch down program
		void program540(); //Hover over pad and land

		// Sub yaw programs
		void program300(); //YAW PROGRAM Hover
		void program700(); //YAW PROGRAM Main and retro Engine
		
		// Sub bank programs
		void program310(); //Bank PROGRAM I Hover
		void program320(); //Bank Program II Hover
		void program330(); //Bank Program III Hover
		
		void program710();	//BANK PROGRAM I Main Engine
		void program715();	//BANK PROGRAM I RETRO Engine
		
		VECTOR3 pos;
		VECTOR3 horizonAirspeedVector;
	
		double interceptPoint;
		double preHold;
		double requiredHorizontalAccelerationToInterceptPoint;
		double requiredHorizontalAccelerationToBase;
		double horizontalSpeedVectorHeading;
		double getRequiredVerticalAcceleration(double interceptAlt);
		double getRequiredVerticalAccelerationBase(double interceptAlt); // New to test
		double getRequiredVerticalAccelerationMain(double interceptAlt);
		void getMaxElevationAngleToBase();
		double getSaveAlt(VESSEL* VLAP, double offset);
		double scanResolution = 10;
		double rangePerScan = 10000;
		double terrainAngel;
		double scanRangeEndLast;
		double maxMountainAngleFromVesselCurrentScan = 0;		
		double distanceToMaxElevationFromBaseCurrentScan = 0;
		double yawFinal = 0;
		double maxElevationAngleCurrentScan = PI2;
		VECTOR3 getYPRSpeedSetpointsByDeltaPhy3(VECTOR3 dp);		
		int updateFlag;
		double dirVectorOld = 0;
		VECTOR3 dvOld;
		double getEngineLevelForIgnition();
		VECTOR3 v_groundspdold;
		double r_degLast = 0;
		double getAltitudeAtDistance(double distance);
		double getAltitudeAtDt(double dt);
		
		//double inetgral_error = 0;
		//bool iIsActive = false;
		//double error_last = 0;
};
#endif