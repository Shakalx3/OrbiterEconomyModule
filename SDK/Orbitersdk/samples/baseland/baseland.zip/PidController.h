#pragma once
// NOT USED YET!
// https://tttapa.github.io/Pages/Arduino/Control-Theory/Motor-Fader/PID-Cpp-Implementation.html

class PIDController
{
	public:
		PIDController(double Kp, double Ki, double Kd, double iMax, double iMin) : _Kp(Kp), _Ki(Ki), _Kd(Kd), _iMax(iMax), _iMin(iMin)
		{			
		}

		double calculate(double sollWert, double istWert, double dt)
		{
			const double error = sollWert - istWert;
			const double pOut = error * _Kp;
			const double iDiff = error * dt;

			integral += iDiff;
			double pI = integral * _Ki;
			const double differenzial = (error - errorLastStep) / dt;			
			double out = pOut + integral + differenzial;
			const bool saturationCheck = out < _iMax && out > _iMin;
			const bool signCheck = ((out < 0) == (error < 0));
			if (saturationCheck && signCheck)
			{
				integral -= iDiff;
				out -= integral;
			}
			errorLastStep = error;
			return out;
		}

	private:
		double _Kp, _Ki, _Kd;
		double _iMax, _iMin;
		double integral;
		double errorLastStep;

};
