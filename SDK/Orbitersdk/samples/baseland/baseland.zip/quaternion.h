#ifndef QUATERNION_H
#define QUATERNION_H
#include "includes.h"

class quaternion
{
	public:
		double x, y, z, w;
		void yprToQuat(VECTOR3 ypr)
		{
			// Create quaternian from setpoints
			double c1 = cos((ypr.z - PI05)/2);
			double s1 = sin((ypr.z - PI05)/2);
			double c2 = cos(ypr.y/2);
			double s2 = sin(ypr.y/2);
			double c3 = cos(-ypr.x/2);
			double s3 = sin(-ypr.x/2);
			double c1c2 = c1*c2;
			double s1s2 = s1*s2;

			w = c1c2*c3 - s1s2*s3;
  			x = c1c2*s3 + s1s2*c3;
			y = s1*c2*c3 + c1*s2*s3;
			z = c1*s2*c3 - s1*c2*s3;
		}
		
		void set(VECTOR3 ypr) //(This is correct)
		{
			set(ypr.y, ypr.x, ypr.z);
		}

		void set(double yaw, double pitch, double roll)
		{
			// Abbreviations for the various angular functions
			double cy = cos(yaw * 0.5);
			double sy = sin(yaw * 0.5);
			double cp = cos(pitch * 0.5);
			double sp = sin(pitch * 0.5);
			double cr = cos(roll * 0.5);
			double sr = sin(roll * 0.5);

			//Quaternion q;
			this->w = cr * cp * cy + sr * sp * sy;
			this->x = sr * cp * cy - cr * sp * sy;
			this->y = cr * sp * cy + sr * cp * sy;
			this->z = cr * cp * sy - sr * sp * cy;
		}

		void set(MATRIX3 m1)
		{
			w = sqrt(1.0 + m1.m11 + m1.m22 + m1.m33) / 2.0;
			double w4 = (4.0 * w);
			x = (m1.m32 - m1.m23) / w4;
			y = (m1.m13 - m1.m31) / w4;
			z = (m1.m21 - m1.m12) / w4;
		}

		quaternion()
		{
			this->w = 0;
			this->x = 0;
			this->y = 0;
			this->z = 0;
		}
		quaternion(double w, double x, double y, double z)
		{			
			this->w = w;
			this->x = x;
			this->y = y;
			this->z = z;
		}

		MATRIX3 getMatrix()
		{
			// create matrix from the set point quaternions
			double sqw = w*w;
			double sqx = x*x;
			double sqy = y*y;
			double sqz = z*z;

			// invers (inverse square length) is only required if quaternion is not already normalised
			double invs = 1 / (sqx + sqy + sqz + sqw);

			MATRIX3 mq;
			mq.m11 = ( sqx - sqy - sqz + sqw)*invs ; // since sqw + sqx + sqy + sqz =1/invs*invs
			mq.m22 = (-sqx + sqy - sqz + sqw)*invs ;
			mq.m33 = (-sqx - sqy + sqz + sqw)*invs ;
    
			double tmp1 = x*y;
			double tmp2 = z*w;
			mq.m21 = 2.0 * (tmp1 + tmp2)*invs ;
			mq.m12 = 2.0 * (tmp1 - tmp2)*invs ;
    
			tmp1 = x*z;
			tmp2 = y*w;
			mq.m31 = 2.0 * (tmp1 - tmp2)*invs ;
			mq.m13 = 2.0 * (tmp1 + tmp2)*invs ;
			tmp1 = y*z;
			tmp2 = x*w;
			mq.m32 = 2.0 * (tmp1 + tmp2)*invs ;
			mq.m23 = 2.0 * (tmp1 - tmp2)*invs ; 
			return mq;
		}

		VECTOR3 ToEulerAngles() 
		{
			VECTOR3 angles;

			// roll (x-axis rotation)
			double sinr_cosp = 2 * (this->w * this->x + this->y * this->z);
			double cosr_cosp = 1 - 2 * (this->x * this->x + this->y * this->y);
			angles.z = std::atan2(sinr_cosp, cosr_cosp);

			// pitch (y-axis rotation)
			double sinp = 2 * (this->w * this->y - this->z * this->x);
			if (std::abs(sinp) >= 1)
				angles.x = std::copysign(PI / 2, sinp); // use 90 degrees if out of range
			else
				angles.x = std::asin(sinp);

			// yaw (z-axis rotation)
			double siny_cosp = 2 * (this->w * this->z + this->x * this->y);
			double cosy_cosp = 1 - 2 * (this->y * this->y + this->z * this->z);
			angles.y = std::atan2(siny_cosp, cosy_cosp);
			
			/*
				x = pitch
				y = yaw 
				z = roll
			*/
			return angles;
		}

		void inverse()
		{
			quaternion q = (*this);
			q.conjugate();
			(*this) = q / quaternion::dot((*this), (*this));
		}

		static quaternion diff(const quaternion &a, const quaternion &b)
		{
			quaternion inv = a;
			inv.inverse();
			return inv * b;
		}

		void conjugate()
		{
			quaternion q;
			q.x = -this->x;
			q.y = -this->y;
			q.z = -this->z;
			q.w = this->w;
			(*this) = q;
		}

		static double dot(const quaternion &q1, const quaternion &q2)
		{
			return q1.x*q2.x + q1.y*q2.y + q1.z*q2.z + q1.w*q2.w;
		}

		const quaternion operator* (const quaternion &q) const
		{
			quaternion qu;
			qu.x = this->w*q.x + this->x*q.w + this->y*q.z - this->z*q.y;
			qu.y = this->w*q.y + this->y*q.w + this->z*q.x - this->x*q.z;
			qu.z = this->w*q.z + this->z*q.w + this->x*q.y - this->y*q.x;
			qu.w = this->w*q.w - this->x*q.x - this->y*q.y - this->z*q.z;
			return qu;
		}

		const quaternion operator/ (float s) const
		{
			quaternion q = (*this);			
			return quaternion(q.x / s, q.y / s, q.z / s, q.w / s);
		}
};

#endif