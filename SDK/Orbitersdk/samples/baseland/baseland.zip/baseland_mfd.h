#ifndef ALPHA_MFD_H
#define ALPHA_MFD_H
#include "includes.h"

#define toRad *0.01745329251994329576923690768489
#define toDeg *(180/PI)
#define MFDMAXLINES 20
using namespace std;

class BaselandMFD : public MFD2
{
public:
	BaselandMFD(DWORD w, DWORD h, VESSEL *vessel, unsigned int mfd);
	~BaselandMFD();
	//virtual void WriteStatus(FILEHANDLE scn) const;
	//virtual void ReadStatus(FILEHANDLE scn);

	bool ConsumeKeyBuffered(DWORD key);
	bool BaselandMFD::Update(oapi::Sketchpad *skp);
	static int MsgProc(UINT msg, UINT mfinald, WPARAM wparam, LPARAM lparam);
	int ButtonMenu(const MFDBUTTONMENU **menu) const;
	char *ButtonLabel(int bt);
	bool ConsumeButton(int bt, int event);
protected:
	int height;
	int width;
private:
	void plotPathPoint(oapi::Sketchpad * skp, double shipAltY, VECTOR3 p);	
	//double getAltitudeAtDistance(double distance, double*dt, bool returndt = true);
	double getAltitudeAtDt(double dt);
	//double getAltitudeAtDt2(double dt);
	//double getAltitudeAtDistance(double distance);
	//double getDtForDistance(double distance);
	//double getDtForDistance2(double distance);

	void drawFlightPath(oapi::Sketchpad *skp);
	//double getAltitudeAtDistance();
	//double getAltitudeAtDistance(double distance);

	int line(int);
	int col(int i);
	//bool inputData(void *id, char *str, void *usrdata);
	void matrixOut(int startline, MATRIX3 m);

	//void drawTopoMap(oapi::Sketchpad *skp);

	//double totalDistance = 50000;
	//double totalAlt = 50000;
	double scaleX;
	double scaleY;
	double qh; //Position of the base altitiute when drawing the landscape. 1.1 means 10% from the buttom of the MFD ???
	void drawLandscape(oapi::Sketchpad *skp);
	void drawLines(oapi::Sketchpad *skp);
	void drawVesselIndicator(oapi::Sketchpad *skp);

	void drawApChannels(oapi::Sketchpad *skp);
	void drawLineBuffer(oapi::Sketchpad *skp);
	//bool inputData(char* data);
	void markText(int line, int x, int fontsize, int space, string text, int linemode, oapi::Sketchpad *skp);
	void displayMenue(oapi::Sketchpad *skp);

	//MyClass * p1 = new MyClass[5];
	std::stringstream *lineBuffer = new stringstream[MFDMAXLINES];
	void createSkpTools();
	void releaseSkpTools();
	double distancePerPixel = 0;

	oapi::Brush *stdBruschDarkGreenLandscape = NULL;
	oapi::Brush *stdBruschDarkGreenRest = NULL;
	oapi::Brush *stdBruschGreen = NULL;
	oapi::Pen *stdPenDarkGreen = NULL;
	oapi::Pen *stdPenDarkGreenApChannels = NULL;
	oapi::Pen *stdPenGreen = NULL;
	oapi::Pen *stdPenYellow = NULL;
	oapi::Pen *stdPenLightGrey = NULL;
	oapi::Pen *stdPenRed = NULL;
	oapi::Pen *stdPenGreenTextLight = NULL;
	oapi::Pen *stdPenGreenTextDark = NULL;
	oapi::Pen *stdPenDarkGreenLandscape = NULL;
	

};
#endif