﻿
/*
TODO:
	- Radarwerte speichern
	- Radar nicht anzeigen
	- Übernahme Zieldaten erst bei klick auf Ok
	- Button in Page umbenennen
	- Seitenzahl statt zoom anzeigen
	- "Saubere" zoom werte
	- Configpage einrichten (safty alt eingeben, draw indicator, draw landscape, draw linebuffer, landscape resolution)	
	- Grundlinie etwas heller machen
	- Thrustergroup reseten wenn YPR deaktiviert werden

	- Indicator circle auf 5° oder so kalibrieren - done
*/

#include "includes.h"

#define		MFD_AP_ON_OFF				OAPI_KEY_A
#define		MFD_YAW_ON_OFF				OAPI_KEY_Y
#define		MFD_PITCH_ON_OFF			OAPI_KEY_P
#define		MFD_ROLL_ON_OFF				OAPI_KEY_R
#define		MFD_VERT_ACCEL_ON_OFF		OAPI_KEY_E
#define		MFD_SET_YPR					OAPI_KEY_RETURN
#define		MFD_ZOOM_PLUS				OAPI_KEY_ADD
#define		MFD_ZOOM_MINUS				OAPI_KEY_MINUS
#define		MFD_SET_TARGET				OAPI_KEY_T
#define		MFD_RESET					OAPI_KEY_B
#define		MFD_MARKPOINT				OAPI_KEY_M
#define		MFD_IGNITE					OAPI_KEY_I
//#define		MFD_CIRCLEPROGRAMMODES		OAPI_KEY_P
#define		MFD_MEN_UP					OAPI_KEY_W //0x8C//OAPI_KEY_8 //104		//OAPI_KEY_NUMPAD8
#define		MFD_MEN_DOWN				OAPI_KEY_S //0xD0//OAPI_KEY_2 //98			//OAPI_KEY_NUMPAD2
#define		MFD_MEN_LEFT				OAPI_KEY_A //0xCB//OAPI_KEY_4 //100		//OAPI_KEY_NUMPAD4
#define		MFD_MEN_RIGHT				OAPI_KEY_D //0xCD//OAPI_KEY_6 //102		//OAPI_KEY_NUMPAD6

extern std::vector<autopilot*> autopilots;
autopilot *mfdi;

BaselandMFD::BaselandMFD (DWORD w, DWORD h, VESSEL *vessel, unsigned int mfd) : MFD2 (w, h, vessel)
{
	height = h;
	width = w;
	qh = 1.1;
}

BaselandMFD::~BaselandMFD ()
{
	delete[] lineBuffer;
}

int BaselandMFD::MsgProc (UINT msg, UINT mfinald, WPARAM wparam, LPARAM lparam)
{
	switch (msg) 
	{
		case OAPI_MSG_MFD_OPENEDEX: 
		{
			MFDMODEOPENSPEC *ospec = (MFDMODEOPENSPEC*)wparam;
			return (int) (new BaselandMFD (ospec->w, ospec->h, (VESSEL*)lparam, mfinald));
		}
	}
	return 0;
}


bool BaselandMFD::ConsumeKeyBuffered (DWORD key)
{
	//this->mfddata = mfdh.getVesselData(oapiGetFocusInterface()->GetHandle());	
	//const double rcsdeltasteps = 5 toRad;
	if (true)
	{
		if (key == MFD_SET_TARGET)
		{
			if (mfdi->menue_data->menuemode == 1)
			{			
				if (mfdi->menue_data->currentTargetMode != mfdi->menue_data->NO_TARGET)
				{
				
				}
				else
				{
					mfdi->masterChannel = false;
					mfdi->yawChannel = false;
					mfdi->pitchChannel = false;
					mfdi->rollChannel = false;
					mfdi->vaChannel = false;
				}
				mfdi->menue_data->menuemode = 0;
			}
			else if (mfdi->menue_data->menuemode == 0) 
			{ 
				mfdi->menue_data->menuemode = 1;
			}		
		}

		if (mfdi->menue_data->menuemode == 0)
		{
			switch (key)
			{
				case MFD_AP_ON_OFF:
				{
					if (mfdi->menue_data->currentTargetMode != mfdi->menue_data->NO_TARGET)
						mfdi->masterChannel = !mfdi->masterChannel;
					if (!mfdi->masterChannel)
					{
						mfdi->yawChannel = false;
						mfdi->pitchChannel = false;
						mfdi->rollChannel = false;
						mfdi->vaChannel = false;
					}
					mfdi->resetThruster();
					break;
				}

				case MFD_YAW_ON_OFF:
				{
					
					mfdi->yawChannel = !mfdi->yawChannel;
					mfdi->resetThruster();
					break;
				}

				case MFD_PITCH_ON_OFF:
				{

					mfdi->pitchChannel = !mfdi->pitchChannel;
					mfdi->resetThruster();
					break;
				}

				case MFD_ROLL_ON_OFF:
				{
					mfdi->rollChannel = !mfdi->rollChannel;
					mfdi->resetThruster();
					break;
				}

				case MFD_VERT_ACCEL_ON_OFF:
				{
					mfdi->vaChannel = !mfdi->vaChannel;					
					break;
				}

				case MFD_ZOOM_PLUS:
				{
					/*
					if (mfdi->menue_data->totalAltZoom > 370)
					{
						mfdi->menue_data->totalAltZoom /= 1.25;
						mfdi->menue_data->totalDistanceZoom /= 1.25;						
					}
					*/
					if (mfdi->menue_data->zoomPtr > 0)
					{
						mfdi->menue_data->zoomPtr--;
						mfdi->menue_data->totalAltZoom = mfdi->menue_data->zoomList[mfdi->menue_data->zoomPtr];
						mfdi->menue_data->totalDistanceZoom = mfdi->menue_data->zoomList[mfdi->menue_data->zoomPtr];
						
					}
					
					break;
				}

				case MFD_ZOOM_MINUS:
				{
					if (mfdi->menue_data->zoomPtr + 1 < mfdi->menue_data->nZoomLvl)
					{
						mfdi->menue_data->zoomPtr++;
						mfdi->menue_data->totalAltZoom = mfdi->menue_data->zoomList[mfdi->menue_data->zoomPtr];
						mfdi->menue_data->totalDistanceZoom = mfdi->menue_data->zoomList[mfdi->menue_data->zoomPtr];

					}

					break;
				}
				case MFD_MARKPOINT:
				{
					VECTOR3 pos;
					oapiGetFocusInterface()->GetEquPos(pos.x, pos.y, pos.z);
					pos.z = 0;
					mfdi->targetPoint = pos;
					mfdi->menue_data->currentTargetMode = mfdi->menue_data->MANUAL;
					mfdi->baseElevation = oapiIsVessel(mfdi->v->GetHandle()) ? oapiSurfaceElevation(mfdi->v->GetGravityRef(), mfdi->targetPoint.x, mfdi->targetPoint.y) : 0;
					break;
				}
				case MFD_RESET:
				{
					mfdi->menue_data->currentTargetMode = mfdi->menue_data->NO_TARGET;
					VECTOR3 pos{ 0, 0, 0 };
					mfdi->targetPoint = pos;
					mfdi->baseElevation = 0;
					mfdi->ptrProgram = 400;
					mfdi->menue_data->currentBaseIndex = 0;
					mfdi->menue_data->currentBasePadIndex = -1;
					mfdi->masterChannel = false;
					mfdi->pitchChannel = false;
					mfdi->yawChannel = false;
					mfdi->rollChannel = false;
					mfdi->vaChannel = false;
					mfdi->menue_data->currentCursorLine = 0;
					mfdi->menue_data->currentNavSourceBase = 0;
					mfdi->menue_data->currentNavSourcePad = 0;
					break;
				}
				case MFD_IGNITE:
				{
					switch (mfdi->ptrProgram)
					{
						case 400 : mfdi->ptrProgram = 405; break;
						case 405: mfdi->ptrProgram = 410; break;
						case 600: mfdi->ptrProgram = 605; break;
						case 605: mfdi->ptrProgram = 610; break;
						case 650: mfdi->ptrProgram = 655; break;
						case 655: mfdi->ptrProgram = 660; break;
						break;
					}
					/*
					if (mfdi->ptrProgram == 400 || mfdi->ptrProgram == 405) mfdi->ptrProgram = 410;

					else if (mfdi->ptrProgram == 600 || mfdi->ptrProgram == 605) mfdi->ptrProgram = 610;
					else if (mfdi->ptrProgram == 650 || mfdi->ptrProgram == 655) mfdi->ptrProgram = 660;
					*/
				}
				default: break;
			}
		}
		else if (mfdi->menue_data->menuemode == 1)
		{
			switch (key)
			{
				/*
				case MFD_CANCEL:
				{
					mfdi->menue_data->menuemode = 0;
					//mfdi->menue_data->currentBaseIndex = 1;
					//mfdi->menue_data->currentBasePadIndex = 1;
					//mfdi->menue_data->currentTargetMode == mfd_data::BASE;
				}
				*/
				case MFD_MEN_UP:
				{
					mfdi->menue_data->decLine();
					break;
				}
				case MFD_MEN_DOWN:
				{
					//if (menue_data->menuemode == 1)
					{
						mfdi->menue_data->incLine();
						
						
						if (mfdi->menue_data->currentTargetMode == mfdi->menue_data->MANUAL && mfdi->menue_data->getMaxLines(mfdi->menue_data->MANUAL) == mfdi->menue_data->currentCursorLine)
						{
							bool inputData(void *id, char *str, void *usrdata);
							oapiOpenInputBox("Enter Target LAT SPACE LNG, minus is WEST and SOUTH, EXAMPLE:\"-32.234 44.98\"", inputData, 0, 20, (void*)this);
							//mfdi->menue_data->currentCursorLine = mfd_data::LINE2;
						}
						
					}
					break;			
				}
				case MFD_MEN_LEFT:
				{
					mfdi->menue_data->decItem();
					break;
				}
				case MFD_MEN_RIGHT:
				{
					mfdi->menue_data->incItem();
					break;
				}
			}
		}

	}
	this->InvalidateButtons();	

	//mfdi->targetPoint.x = mfdi->menue_data->lng;
	//mfdi->targetPoint.y = mfdi->menue_data->lat;

	return false;
}

//This function gives us the pixel of the Line "i"...
int BaselandMFD::line( int i )
{
   return (int)((float)i*((float)height/20.0));   
}

int BaselandMFD::col( int i )
{
   return (int)((float)i*((float)width/60.0));
}

//Here comes the caption for the help-menue of our MFD.
int BaselandMFD::ButtonMenu (const MFDBUTTONMENU **menu) const
{
	for (unsigned i = 0; i < oapiGetVesselCount(); i++)  //Get the right autopilot interface for the current vessel which shows this MFD
	{
		autopilot *ap = autopilots.at(i);
		if (ap->getVessel() == oapiGetFocusInterface())
		{
			mfdi = ap;
			break;
		}
	}
	if (mfdi->menue_data->menuemode == 0)
	{
		static const MFDBUTTONMENU mnu[12] =
		{
			{"AP MASTER", "PWR", 'A'},
			{"RESET PROGRAM", "", 'Q'},			
			{"YAW CHANNEL", "PWR", 'Y'},
			{"PITCH CHANNEL", "PWR", 'P' },
			{"ROLL CHANNEL", "PWR", 'R'},
			{"ENGINE CHANNEL", "PWR", 'V'},

			{"SELECT TARGET", 0, 'T'},
			{"STEP FORWARD TO", "NEXT PROGRAM", 'I'},
			{"MARK CURRENT POS", "FOR LANDING", 'M'},
			{"CIRCLE PROGRAM MODES", 0 ,'P'},

			{"Zoom +", 0, 'NUM+'},
			{"Zoom -", 0, 'NUM-'}

		};
		if (menu) *menu = mnu;
		return 12;
	}
	else if (mfdi->menue_data->menuemode == 1)
	{
		static const MFDBUTTONMENU mnu[12] =
		{
			{ "CURSOR UP", 0, 'W' },
			{ "CURSOR DOWN", 0, 'S' },
			{ "CURSOR LEFT", 0, 'A' },
			{ "CURSOR RIGHT", 0, 'D' },
			{ "", "", 0 },
			{ "", "", 0 },

			{ "CONFIRM TARGET", 0, 'T' },
			{ "", 0, 0 },
			{ "", 0, 0 },
			{ "", 0 , 0 },

			{ "", 0, 0 },
			{ "", 0, 0 }

		};
		if (menu) *menu = mnu;
		return 12;
	}

}

//Here comes the caption for the buttons itselfes.
char *BaselandMFD::ButtonLabel (int bt)
{		
	for (unsigned i = 0; i < oapiGetVesselCount(); i++)  //Get the right autopilot interface for the current vessel which shows this MFD
	{
		autopilot *ap = autopilots.at(i);
		if (ap->getVessel() == oapiGetFocusInterface())
		{
			mfdi = ap;
			break;
		}
	}

	if (mfdi->menue_data->menuemode == 0)
	{
		char *label[] = { "AP","RES","Y","P","R","ENG",
							 "TGT","IGN", "MRK", "","ZM+", "ZM-" };

		return (bt < 12 ? label[bt] : 0);
	}
	else if (mfdi->menue_data->menuemode == 1)
	{
		char *label[] = { "UP","DWN","LFT","RHT","","",
			"OK","", "", "","", "" };

		return (bt < 12 ? label[bt] : 0);

	}

}

//And here we tell what happend by pressing the button by mouse. At this time (i think always),
//we can simple send back the Keycode of the Keyboardchar.
bool BaselandMFD::ConsumeButton(int bt, int event)
{
	for (unsigned i = 0; i < oapiGetVesselCount(); i++)  //Get the right autopilot interface for the current vessel which shows this MFD
	{
		autopilot *ap = autopilots.at(i);
		if (ap->getVessel() == oapiGetFocusInterface())
		{
			mfdi = ap;
			break;
		}
	}

	if (event & PANEL_MOUSE_LBDOWN)
	{
		if (mfdi->menue_data->menuemode == 0)
		{
			switch (bt)
			{
				case(0): return ConsumeKeyBuffered(MFD_AP_ON_OFF);
				case(1): return ConsumeKeyBuffered(MFD_RESET);
				case(2): return ConsumeKeyBuffered(MFD_YAW_ON_OFF);
				case(3): return ConsumeKeyBuffered(MFD_PITCH_ON_OFF);
				case(4): return ConsumeKeyBuffered(MFD_ROLL_ON_OFF);
				case(5): return ConsumeKeyBuffered(MFD_VERT_ACCEL_ON_OFF);
				case(6): return ConsumeKeyBuffered(MFD_SET_TARGET);
				case(7): return ConsumeKeyBuffered(MFD_IGNITE);
				case(8): return ConsumeKeyBuffered(MFD_MARKPOINT);
				//case(9): return ConsumeKeyBuffered(MFD_CIRCLEPROGRAMMODES);
				case(10): return ConsumeKeyBuffered(MFD_ZOOM_PLUS);
				case(11): return ConsumeKeyBuffered(MFD_ZOOM_MINUS);
			}
		}
		else if (mfdi->menue_data->menuemode == 1)
		{
			switch (bt)
			{
				case(0): return ConsumeKeyBuffered(MFD_MEN_UP);
				case(1): return ConsumeKeyBuffered(MFD_MEN_DOWN);
				case(2): return ConsumeKeyBuffered(MFD_MEN_LEFT);
				case(3): return ConsumeKeyBuffered(MFD_MEN_RIGHT);
				case(6): return ConsumeKeyBuffered(MFD_SET_TARGET);
				//case(7): return ConsumeKeyBuffered(MFD_CANCEL);
			}
		}
	}
	return false;
}
/*
void SurfaceSpeedMFD::drawTopoMap(oapi::Sketchpad *skp)
{		
	static double highest = 5000;
	static double lowest = -5000;
	VESSEL*v = oapiGetFocusInterface();
	double lng_Vessel, lat_Vessel, rad;
	v->GetEquPos(lng_Vessel,lat_Vessel,rad);
	double heading = ORBITERTOOLS::getFlightVectorHeading(v);			
	const double zoom = 5000;
	for (int x=-width/2; x<width/2; x++)
	{
		double lng_left, lat_left, rad;
		ORBITERTOOLS::pointRadialDistance(lat_Vessel,lng_Vessel,heading+PI05,x*zoom,v,&lat_left,&lng_left);
		skp->MoveTo(x+width/2,0);
		for (int y=-height/2; y<height/2; y++)
		{			
			double lng_pixel, lat_pixel;
			ORBITERTOOLS::pointRadialDistance(lat_left,lng_left,heading,y*zoom,v,&lat_pixel,&lng_pixel);
			double elevation = oapiSurfaceElevation(v->GetGravityRef(),lng_pixel,lat_pixel);	
			oapi::Pen *elevationPen;
			if (elevation > highest) highest = elevation;
			if (elevation < lowest) lowest = elevation;
			double elevation255 = ((elevation + (0 - lowest)) / ( highest - lowest)) * 255;			
			elevationPen = oapiCreatePen(1, 1, RGB(elevation255,elevation255,elevation255));  // released in 403
			skp->SetPen(elevationPen);
			skp->LineTo(x+width/2, height-(y+height/2));			
			oapiReleasePen(elevationPen);
			//delete elevationPen;
		}

	}	
	delete v;

}
*/

void BaselandMFD::matrixOut(int startline, MATRIX3 m)
{
	lineBuffer[startline++] << m.m11 << " " << m.m12 << " " << m.m13;
	lineBuffer[startline++] << m.m21 << " " << m.m22 << " " << m.m23;
	lineBuffer[startline++] << m.m31 << " " << m.m32 << " " << m.m33;

}

//bool test = true;
bool BaselandMFD::Update (oapi::Sketchpad *skp)
{	
	if (mfdi == NULL) return false;
	createSkpTools();

	scaleX = mfdi->menue_data->totalDistanceZoom / width;
	scaleY = mfdi->menue_data->totalAltZoom / height;	
	
	drawLandscape(skp);
	
	drawLines(skp);
	
	drawFlightPath(skp);

	drawVesselIndicator(skp);
	
	this->Title(skp, "Base Land Autopilot");

	//int maxCols = (30);
	//pixelProZeichen = PixelProZeile / 60.0);

	for (int i = 0; i<20; i++)
	{
		
		lineBuffer[i] << fixed << setprecision(2);
		lineBuffer[i] << internal << showpos;
		lineBuffer[i].str("");
	}
	
	lineBuffer[2] << "Program:	" << (unsigned int) mfdi->ptrProgram;
	lineBuffer[3] << "Pitch: " << mfdi->dv.x toDeg << " Yaw: " << mfdi->dv.y toDeg << " Roll: " << mfdi->dv.z toDeg;
	lineBuffer[4] << noshowpos << setprecision(2) << "Engine:   "  << mfdi->engineLevel * 100.0 << " %";
	//lineBuffer[6] << noshowpos << setprecision(2) << "DRadar:   " << mfdi->terrainScanPtr / 1000 << " km";	
	lineBuffer[6] << noshowpos << setprecision(2) << "MaxElv:     " << setw(10) << mfdi->maxElevation / 1000 << " km";	
	lineBuffer[7] << noshowpos << setprecision(2) << "DistMaxElv: " << setw(10) << mfdi->distanceToMaxElevation / 1000 << " km";
	lineBuffer[8] << noshowpos << setprecision(2) << "RAltMaxElv: " << setw(10) << mfdi->rAltMaxElevation / 1000 << " km";

	lineBuffer[10] << noshowpos << setprecision(2) << "TargetElv:  " << setw(10) << mfdi->baseElevation / 1000 << " km";
	lineBuffer[11] << noshowpos << setprecision(2) << "DistTarget: " << setw(10) << mfdi->distanceToBasePad / 1000 << " km";
	lineBuffer[12] << noshowpos << setprecision(2) << "RAltTarget: " << setw(10) << mfdi->rAltBase / 1000 << " km";
	//lineBuffer[13] << noshowpos << setprecision(2) << "RAltTarget2:" << setw(10) << getAltitudeAtDistance(mfdi->distanceToBasePad) / 1000 << " km";
	//lineBuffer[14] << noshowpos << setprecision(2) << "RAltTarget3:" << setw(10) << mfdi->rAltBase / 1000 << " km";
	
	//matrixOut(10, mfdi->v_matrix);

	//lineBuffer[13] << "M Pitch: " << mfdi->dv.x toDeg << " Yaw: " << mfdi->dv.y toDeg << " Roll: " << mfdi->dv.z toDeg;
	//ineBuffer[14] << "Q Pitch: " << mfdi->dv2.x toDeg << " Yaw: " << mfdi->dv2.y toDeg << " Roll: " << mfdi->dv2.z toDeg;
	//matrixOut(14, mfdi->dm2);
	//lineBuffer[14] << "Q Pitch: " << mfdi->dv2.x toDeg << " Yaw: " << mfdi->dv2.y toDeg << " Roll: " << mfdi->dv2.z toDeg;


	NAVHANDLE nhBase = mfdi->v->GetNavSource(mfdi->menue_data->currentNavSourceBase);
	NAVHANDLE nhPad = mfdi->v->GetNavSource(mfdi->menue_data->currentNavSourcePad);

	VECTOR3 vPos;
	mfdi->v->GetGlobalPos(vPos);
	double baseSignal = 0;
	double padSignal = 0;

	if (nhBase != NULL) baseSignal = log(oapiGetNavSignal(nhBase, vPos));
	if (nhPad != NULL) padSignal = log(oapiGetNavSignal(nhPad, vPos));
	if (mfdi->menue_data->currentTargetMode == mfdi->menue_data->NAVSOURCE)
	{
		if (baseSignal > 0.1) lineBuffer[11] << "RECEIVING BASE NAV";
		if (padSignal > 0.1) lineBuffer[12] << "RECEIVING PAD  NAV";
	}

	//-------------------------------

	//time_t t = time(0);
	//struct tm * now = localtime(&t);
	double systime = oapiGetSysMJD();
	//sprintf(oapiDebugString(), "%f", systime);


	/*
	if (systime > 58026)
	{
		string out = "PLEASE CHECK FOR NEW RELEASE!!";
		skp->Text(col(2), line(2), out.c_str(), out.length());
		return true;
	}
	*/
	for (unsigned i = 0; i < oapiGetVesselCount(); i++)  //Get the right autopilot interface for the current vessel which shows this MFD
	{
		autopilot *ap = autopilots.at(i);
		if (ap->getVessel() == oapiGetFocusInterface())
		{
			mfdi = ap;
			break;
		}
	}
	//mfdi->menue_data->totalAltZoom = zoomList[zoomPtr];
	//mfdi->menue_data->totalDistanceZoom = zoomList[zoomPtr];

	//if (test) mfdi->getVessel()->SendBufferedKey(OAPI_KEY_G);
	//test = false;
	//sprintf(oapiDebugString(), "%f", mfdi->getVessel()->GetWheelbrakeLevel(0));

	mfdi->menue_data->updateLngLat();

	// Draw zoom string in the upper right corner
	stringstream zoomStr;
	zoomStr << fixed << setprecision(0) << 2;
	//zoomStr << internal << showpos;
	zoomStr.str("");

	if (mfdi->menue_data->totalDistanceZoom > 999)
	{
		zoomStr << "Z:" << mfdi->menue_data->totalDistanceZoom / 1000 << "km";
	}
	else
	{
		zoomStr << "Z:" << mfdi->menue_data->totalDistanceZoom << "m";
	}
	
	skp->Text(width - col((zoomStr.str().length()*2)-1), line(0), zoomStr.str().c_str(), zoomStr.str().length());
		

	if (mfdi->menue_data->menuemode == 0)
	{
		drawApChannels(skp);
		if (mfdi->masterChannel)
		{			
			drawLineBuffer(skp);
		}
	}
	else if (mfdi->menue_data->menuemode == 1)
	{
		displayMenue(skp);
	}
	
	releaseSkpTools();
	return true;
}

void BaselandMFD::createSkpTools()
{
	stdBruschDarkGreenLandscape = oapiCreateBrush(RGB(0, 40, 0)); //released in 528
	stdBruschDarkGreenRest = oapiCreateBrush(RGB(0, 100, 0));//released in 649

	stdBruschGreen = oapiCreateBrush(RGB(0, 200, 0)); //released in 648
	stdPenDarkGreen = oapiCreatePen(1, 1, RGB(0, 60, 0));  //released in 525
	stdPenDarkGreenLandscape = oapiCreatePen(1, 1, RGB(0, 40, 0));  //released in 525

	stdPenDarkGreenApChannels = oapiCreatePen(1, 1, RGB(0, 100, 0)); //released in 647
	stdPenGreen = oapiCreatePen(1, 1, RGB(0, 200, 0)); //released in 646	
	stdPenLightGrey = oapiCreatePen(1, 1, RGB(60, 60, 60)); //released in 526
	stdPenRed = oapiCreatePen(1, 1, RGB(255, 0, 0));
	stdPenGreenTextDark = oapiCreatePen(1, 1, RGB(0, 100, 0));  //released in 1179
	stdPenGreenTextLight = oapiCreatePen(1, 1, RGB(0, 255, 0));  //released in 1179

	stdPenYellow = oapiCreatePen(1, 1, RGB(200, 200, 0)); //released in 646	
}

void BaselandMFD::releaseSkpTools()
{
	oapiReleaseBrush(stdBruschDarkGreenLandscape);
	oapiReleaseBrush(stdBruschDarkGreenRest);
	oapiReleaseBrush(stdBruschGreen);
	oapiReleasePen(stdPenDarkGreen);
	oapiReleasePen(stdPenDarkGreenApChannels);
	oapiReleasePen(stdPenGreen);
	oapiReleasePen(stdPenLightGrey);
	oapiReleasePen(stdPenRed);
	oapiReleasePen(stdPenGreenTextDark);
	oapiReleasePen(stdPenGreenTextLight);
	oapiReleasePen(stdPenDarkGreenLandscape);
	oapiReleasePen(stdPenYellow);
	
}
void BaselandMFD::drawLandscape(oapi::Sketchpad *skp)
{	
	distancePerPixel = mfdi->menue_data->totalDistanceZoom / width;
	int lauf = 0;
	long y = 0;

	int resolution = 1;
	//double *yval = new double[width+4];
	//oapi::IVECTOR2 * polypoints = new oapi::IVECTOR2[65]();
	oapi::IVECTOR2 polypoints[65];
	if (true)
	{
		int c = 0;
		int xlast = 0;
		int ylast = 0;
		skp->SetBrush(stdBruschDarkGreenLandscape);
		skp->SetPen(stdPenDarkGreenLandscape);
		int maxPoints = 64;
		for (long x = 0; x < width; x += 1)
		{
			double evaluation = ORBITERTOOLS::getElevationAtDistance(oapiGetFocusInterface(), (x*distancePerPixel) - mfdi->menue_data->totalDistanceZoom / 2);
			y = (long) ((height / qh) - ((evaluation - mfdi->baseElevation) / scaleY));

			//yval[x] = y;
			polypoints[c].x = x;
			polypoints[c].y = y;
			c++;
			if (c == maxPoints - 2)
			{
				polypoints[c].x = x;
				polypoints[c].y = height;
				
				polypoints[c+1].x = xlast;
				polypoints[c+1].y = height;

				polypoints[c + 2].x = xlast;
				polypoints[c + 2].y = ylast;
				
				skp->Polygon(polypoints, maxPoints);
				xlast = x;				 
				ylast = y;
				c = 0;
			}
		}		
		polypoints[c].x = width;
		polypoints[c].y = height;

		polypoints[c + 1].x = xlast;
		polypoints[c + 1].y = height;

		polypoints[c + 2].x = xlast;
		polypoints[c + 2].y = ylast;

		skp->Polygon(polypoints, c+3);
		//xlast = x;
		//ylast = y;
		//c = 0;

	}
	//delete polypoints;


}


void BaselandMFD::plotPathPoint(oapi::Sketchpad *skp, double shipAltY, VECTOR3 p)
{
	/*
	int x = (width / 2) + p.x / distancePerPixel;
	int y = shipAltY - p.y / distancePerPixel;
	skp->SetPen(stdPenYellow);
	skp->LineTo(x, y);
	*/
}


/*
inline double limit(double x)
{
	if (x>PI2) return fmod(x, PI2); if (x<0) return PI2 - fmod(-x, PI2); return x;
}
*/

/*
double BaselandMFD::getDtForDistance(double distance)
{
	OBJHANDLE hRef = mfdi->v->GetGravityRef();
	ORBITPARAM *prm = new ORBITPARAM;
	ELEMENTS el;
	mfdi->v->GetElements(hRef, el, prm);
	double s = oapiGetSize(hRef); //1.737,4 km
	double angle = distance / oapiGetSize(hRef);
	double eca = ORBITERTOOLS::tra2eca(posangle(prm->TrA + angle), el.e);
	const double mnm = sqrt(oapiGetMass(hRef) * GGRAV / fabs(el.a * el.a * el.a));
	const double dm1 = posangle(ORBITERTOOLS::eca2mna(eca, el.e) - prm->MnA);
	double dt1 = dm1 / mnm;
	return dt1; // Travel time for "angle" less than one orbit
}
*/

double BaselandMFD::getAltitudeAtDt(double dt)
{
	ORBITPARAM *prm = new ORBITPARAM;
	ELEMENTS el;
	OBJHANDLE hRef = mfdi->v->GetGravityRef();
	mfdi->v->GetElements(hRef, el, prm);	
	const double mna = prm->MnA + PI2 * dt / prm->T;
	const double eca = ORBITERTOOLS::mna2eca(posangle(mna), el.e);
	return el.a * (1.0 - el.e*cosf(eca)) - oapiGetSize(hRef);
}
/*
double BaselandMFD::getDtForDistance2(double distance)
{
	//distance *= 2;
	ORBITPARAM *prm = new ORBITPARAM;
	ELEMENTS el;
	OBJHANDLE hRef = mfdi->v->GetGravityRef();
	mfdi->v->GetElements(hRef, el, prm);
	double angle = distance / oapiGetSize(hRef);
	double eca = ORBITERTOOLS::tra2eca(posangle(prm->TrA + angle), el.e);
	const double mnm = sqrt(oapiGetMass(hRef) * GGRAV / fabs(el.a * el.a * el.a));
	const double dm = posangle(ORBITERTOOLS::eca2mna(eca, el.e) - prm->MnA);
	return dm / mnm; // Travel time for "angle" less than one orbit
}

double BaselandMFD::getAltitudeAtDt2(double dt)
{
	ORBITPARAM *prm = new ORBITPARAM;
	ELEMENTS el;
	OBJHANDLE hRef = mfdi->v->GetGravityRef();
	mfdi->v->GetElements(hRef, el, prm);
	const double mna = prm->MnA + PI2 * dt / prm->T;
	const double eca = ORBITERTOOLS::mna2eca(posangle(mna), el.e);
	return el.a * (1.0 - el.e*cosf(eca)) - oapiGetSize(hRef);
}
*/
void BaselandMFD::drawFlightPath(oapi::Sketchpad *skp)
{
	const double shipAltY = (height / qh) - ((oapiGetFocusInterface()->GetAltitude(AltitudeMode::ALTMODE_MEANRAD) - mfdi->baseElevation) / scaleY);
	double y = shipAltY;
	skp->SetPen(stdPenYellow);
	skp->MoveTo(width / 2, y);
	double xi = 0;
	double heading = 0;
	oapiGetHeading(mfdi->v->GetHandle(), &heading);
	double heading_v = ORBITERTOOLS::getFlightVectorHeading(mfdi->v);
	
	//sprintf(oapiDebugString(), "%f  %f   ", heading, heading_v);

	double groundspeed = mfdi->v->GetGroundspeed();
	const VECTOR3 v3_base = oapiGetGroundVector(mfdi->v->GetGravityRef(), mfdi->targetPoint.x, mfdi->targetPoint.y);
	const double v_base = length(v3_base);
	// s = v * t
	
	for (int p = 1; p < width; p++)
	{
		const double dt = mfdi->getDtForDistance(p*distancePerPixel); // t		
		double s_base = v_base * dt * -cos(heading_v + PI05);
		double p_base = s_base / distancePerPixel;
		const double x = (width / 2) + p - p_base;
		const double altAtDt = getAltitudeAtDt(dt);
		const double deltaAlt = altAtDt - oapiGetFocusInterface()->GetAltitude();
		const double altPixel = deltaAlt / (distancePerPixel);
		y = shipAltY - altPixel;
		skp->LineTo(x , y);
		if (y > height || x > width) break;
	}
}

/*
mfdi->targetPoint.x = lng * (PI / 180);
mfdi->targetPoint.y = lat * (PI / 180);
*/
/*
double BaselandMFD::getAltitudeAtDistance(double distance)
{
	double latAtDistance, lonAtDistance;
	ORBITERTOOLS::pointRadialDistance(mfdi->v, distance, &latAtDistance, &lonAtDistance);
	if (oapiGetFocusInterface() == mfdi->v)
	{
		sprintf(oapiDebugString(), "%f %f    %f %f", lonAtDistance, latAtDistance, mfdi->targetPoint.x, mfdi->targetPoint.y);
	}
	const VECTOR3 v3_base = oapiGetGroundVector(mfdi->v->GetGravityRef(), lonAtDistance, latAtDistance);

	double heading_v = ORBITERTOOLS::getFlightVectorHeading(mfdi->v);
	double deltaSBase = 0;
	double dt = getDtForDistance(distance);
	const double v_base = length(v3_base);
	double s_base = v_base * dt * cos(heading_v + PI05);
	double dtForS_base = getDtForDistance(fabs(s_base));
	dt = s_base < 0 ? dt + dtForS_base : dt - dtForS_base;
	s_base = v_base * dtForS_base * cos(heading_v + PI05);
	dtForS_base = getDtForDistance(fabs(s_base));
	dt = s_base < 0 ? dt + dtForS_base : dt - dtForS_base;
	double altAtDt = getAltitudeAtDt(dt);
	double dBaseAlt = altAtDt - ORBITERTOOLS::getElevationAtDistance(mfdi->v, distance);
	return dBaseAlt;
}

double BaselandMFD::getAltitudeAtDistance()
{
	mfdi->targetPoint.x = lng * (PI / 180);
	mfdi->targetPoint.y = lat * (PI / 180);
	
	const VECTOR3 v3_base = oapiGetGroundVector(mfdi->v->GetGravityRef(), mfdi->targetPoint.x, mfdi->targetPoint.y);
	const double v_base = length(v3_base);
	double heading_v = ORBITERTOOLS::getFlightVectorHeading(mfdi->v);
	double deltaSBase = 0;
	double dt = getDtForDistance(mfdi->distanceToBasePad);
	double s_base = v_base * dt * cos(heading_v + PI05);
	double dtForS_base = getDtForDistance(fabs(s_base));
	dt = s_base < 0 ? dt + dtForS_base : dt - dtForS_base;
	s_base = v_base * dtForS_base * cos(heading_v + PI05);
	dtForS_base = getDtForDistance(fabs(s_base));
	dt = s_base < 0 ? dt + dtForS_base : dt - dtForS_base;
	double altAtDt = getAltitudeAtDt(dt);
	double dBaseAlt = altAtDt - mfdi->baseElevation;
	return dBaseAlt;		
}
*/
void BaselandMFD::drawLines(oapi::Sketchpad *skp)
{
	//----- Draw the ship (Vessel cross)
	skp->SetPen(stdPenGreen);
	double shipAltY = (height / qh) - ((oapiGetFocusInterface()->GetAltitude(AltitudeMode::ALTMODE_MEANRAD) - mfdi->baseElevation) / scaleY);
	skp->Line((width / 2) - 5, shipAltY, (width / 2) + 5, shipAltY);
	skp->Line(width / 2, shipAltY + 5, width / 2, shipAltY - 5);
	
	VECTOR3 verticalSpeedCurrent;
	mfdi->v->GetAirspeedVector(FRAME_HORIZON, verticalSpeedCurrent);
	double vSpeed = verticalSpeedCurrent.y;
	


	//int y0 = (height / qh) - ((-mfdi->menue_data->totalAltZoom) / scaleY);
	int y0 = (height / qh) - ((-mfdi->baseElevation) / scaleY);

	skp->SetPen(stdPenLightGrey);
	skp->Line(0, y0, width, y0);	//draw zero altitude line

	if (!mfdi->menue_data->currentTargetMode == mfd_data::NO_TARGET)
	{
		double baseDistance = mfdi->distanceToBasePad;
		double maxElevationDistance = mfdi->distanceToMaxElevation;
		if (!mfdi->closingBase)
		{
			baseDistance *= -1;
			maxElevationDistance *= -1;
		}
		//----- Draw the max elevation angle point
		skp->SetPen(stdPenGreen);

		int xMaxElevation = (maxElevationDistance / scaleX) + width / 2;
		int yMaxElevation = (height / qh) - ((mfdi->maxElevation + mfdi->inteceptAlt - mfdi->baseElevation) / scaleY);

		//----- Draw the base point
		int xBase = (baseDistance / scaleX) + width / 2;
		int yBase = (height / qh) ;
		int xInteceptPoint = (mfdi->distanceToInterceptPont / scaleX) + width / 2;
		int yInteceptPoint = (height / qh) - ((mfdi->baseElevation + mfdi->inteceptAlt - mfdi->baseElevation) / scaleY);
		

		//Base InteceptAlt to vessel
		if (mfdi->ptrProgram != 540)
		{
			skp->SetPen(stdPenDarkGreen);
			
			skp->Line(xMaxElevation, yMaxElevation, width / 2, (int) shipAltY);  //Line between ship and max elevation
			
			//skp->MoveTo(width / 2, (height / qh) - ((mfdi->v->GetAltitude() + mfdi->inteceptAlt - mfdi->baseElevation) / scaleY));
			
			if (oapiGetFocusInterface() == mfdi->v)
			{
				//sprintf(oapiDebugString(), "%f", mfdi->v->GetAltitude());
			}
			/*
			for (int px = width / 2; px < width; px++)
			{
				double s = (px - width / 2) * distancePerPixel;
				//oapiGetFocusInterface()->GetAltitude(AltitudeMode::ALTMODE_MEANRAD)
				//hSolls = (s / smax * v->GetAltitude()) + interceptAlt + maxElevation;
                //     5000 		      4100               -900
				double diff = mfdi->v->GetAltitude() - mfdi->maxElevation;
				double hLos = mfdi->v->GetAltitude() - (mfdi->v->GetAltitude() - mfdi->maxElevation) / maxElevationDistance * s;
				// 5000 in 100km
				//    ? in   1km
				//  5000 / 100 * s
				//   50 in   1km
				//double py = (height / qh) - ((hLos + mfdi->inteceptAlt - mfdi->baseElevation) / scaleY);
				double py = (height / qh) - ((hLos - mfdi->baseElevation) / scaleY);

				//double hSolls = (s / smax * v->GetAltitude()) + interceptAlt + maxElevation;
				skp->LineTo(px,py);
			}
			*/
			skp->Line(xMaxElevation, yMaxElevation - (height / 16), xMaxElevation, yMaxElevation);	//Vertical line at max elevation
			skp->SetPen(stdPenGreen);
			skp->Line(xBase, yBase - (height / 16), xBase, yBase);  //Vertical line at base
			skp->SetPen(stdPenRed);
			skp->Line(0, yMaxElevation, height, yMaxElevation); // horizontal line at max elevation
			skp->SetPen(stdPenGreen);
			skp->Line(0, yBase, width, yBase);   // horizontal line at base
		}
		else
		{
			skp->SetPen(stdPenGreen);
			skp->Line(xBase, yBase, width / 2, (int) shipAltY);
			skp->Line(0, yBase, width, yBase);   // horizontal line at base
		}
		//Draw vertical speed indicator line
		//skp->SetPen(stdPenGreen);
		//const int vectorLength = width / 4;		
		//const double distance_Vector = distancePerPixel * vectorLength;
		//const double t_vectorlength = distance_Vector / (mfdi->HorizontalSpeed / 2);
		//const double da = mfdi->v->get
		//double phy = atan2(vSpeed, mfdi->HorizontalSpeed);
		
		//sprintf(oapiDebugString(), "%f", mfdi->menue_data->totalDistanceZoom);
		//skp->Pixel()
		

		
		//drawFlightPath(skp, shipAltY, true);
		
		/*
		skp->Line(width / 2, shipAltY, width / 2, shipAltY);
		double altLastDraw = oapiGetFocusInterface()->GetAltitude(AltitudeMode::ALTMODE_MEANRAD);
		for (int x = 0; x < width/2; x++)
		{
			//mfdi->getAltAtDistance(x*distancePerPixel);
			//skp->Pixel(width / 2 + x, mfdi->getAltAtDistance(distancePerPixel*x),RGB(1,0,0));
			double alt = mfdi->getAltAtDistance(distancePerPixel*x);
			if (alt != 0 && alt != altLastDraw)
			{
				double y = (height / qh) - ((alt - mfdi->baseElevation) / scaleY);
				skp->LineTo((width / 2) + x, y);
				altLastDraw = alt;
			}

			//skp->Line(width / 2, shipAltY, width / 2 + cos(phy) * vectorLength, shipAltY - sin(phy) * vectorLength);
		}
		*/
		
	}
}

void BaselandMFD::drawVesselIndicator(oapi::Sketchpad *skp)
{
	//Draw vessel indicator
	skp->SetBrush(NULL);
	int r = width / 10;
	skp->SetPen(stdPenDarkGreen);
	skp->Ellipse((width / 2) - r, (height / 2) - r, (width / 2) + r, (height / 2) + r);
	skp->SetPen(stdPenGreen);
	const double degForCircle = 5;
	int oy = -((int) ((mfdi->dv.x toDeg * 2 * r)/ degForCircle));
	int ox = -((int) ((mfdi->dv.y toDeg * 2 * r)/ degForCircle));
	

	double oz = (mfdi->dv.z);
	
	double xc = (width / 2)  + ox;
	double yc = (height / 2) + oy;	
	if (xc < 0) xc = 0;
	if (xc > width) xc = width;
	if (yc < 0) yc = 0;
	if (yc > height) yc = height;


	skp->Ellipse(xc - r, (int) yc - r, (int) xc + r, (int) yc + r);
	
	double line1x = xc;
	double line1y = yc - r;
	double xline1 = (xc + (line1x-xc) * cos(oz) - (line1y-yc) * sin(oz));
	double yline1 = (yc + (line1y-yc) * cos(oz) + (line1x-xc) * sin(oz));
	skp->Line(xc, yc, int(xline1 + 0.5), int(yline1 + 0.5));

	line1x = xc - r;
	line1y = yc;
	xline1 = (xc + (line1x - xc) * cos(oz) - (line1y - yc) * sin(oz));
	yline1 = (yc + (line1y - yc) * cos(oz) + (line1x - xc) * sin(oz));
	skp->Line(xc, yc, int(xline1 + 0.5), int(yline1 + 0.5));

	line1x = xc + r;
	line1y = yc;
	xline1 = (xc + (line1x - xc) * cos(oz) - (line1y - yc) * sin(oz));
	yline1 = (yc + (line1y - yc) * cos(oz) + (line1x - xc) * sin(oz));
	skp->Line(xc, yc, int(xline1+0.5), int(yline1+0.5));
}

void BaselandMFD::drawApChannels(oapi::Sketchpad *skp)
{
	static int l;
	l++;
	skp->SetBrush(stdBruschDarkGreenRest);
	skp->SetPen(stdPenGreenTextDark);
	if (mfdi->masterChannel)
	{
		if (mfdi->yawChannel || mfdi->pitchChannel || mfdi->rollChannel || mfdi->vaChannel)
		{
			skp->SetPen(stdPenGreen);
			skp->SetBrush(stdBruschGreen);
		}
		else if (l % 9 < 5)
		{
			skp->SetPen(stdPenGreen);
			skp->SetBrush(stdBruschGreen);
		}

	}
	skp->Rectangle(col(1), line(1), col(43), line(2));
	skp->SetBrush(stdBruschGreen);
	skp->SetPen(stdPenGreen);
	const double maxDiff = 0.005;
	if (mfdi->yawChannel)
	{

		if (l % 4 < 2 && abs(mfdi->dv.y) > maxDiff)
		{
			skp->SetBrush(stdBruschDarkGreenRest);
			skp->SetPen(stdPenGreenTextDark);
		}
		else
		{
			skp->SetBrush(stdBruschGreen);
			skp->SetPen(stdPenGreen);
		}
	}
	else
	{
		skp->SetBrush(stdBruschDarkGreenRest);
		skp->SetPen(stdPenGreenTextDark);
	}
	skp->Rectangle(col(1), line(2), col(8), line(3));

	if (mfdi->pitchChannel)
	{
		if (l % 4 < 2 && abs(mfdi->dv.x) > maxDiff)
		{
			skp->SetBrush(stdBruschDarkGreenRest);
			skp->SetPen(stdPenGreenTextDark);
		}
		else
		{
			skp->SetBrush(stdBruschGreen);
			skp->SetPen(stdPenGreen);
		}
	}
	else
	{
		skp->SetBrush(stdBruschDarkGreenRest);
		skp->SetPen(stdPenGreenTextDark);
	}

	skp->Rectangle(col(8), line(2), col(18), line(3));
	if (mfdi->rollChannel)
	{
		if (l % 4 < 2 && abs(mfdi->dv.z) > maxDiff)
		{
			skp->SetBrush(stdBruschDarkGreenRest);
			skp->SetPen(stdPenGreenTextDark);
		}
		else
		{
			skp->SetBrush(stdBruschGreen);
			skp->SetPen(stdPenGreen);
		}
	}
	else
	{
		skp->SetBrush(stdBruschDarkGreenRest);
		skp->SetPen(stdPenGreenTextDark);
	}
	skp->Rectangle(col(18), line(2), col(28), line(3));

	if (mfdi->vaChannel)
	{
		skp->SetBrush(stdBruschGreen);
		skp->SetPen(stdPenGreen);
	}
	else
	{
		skp->SetBrush(stdBruschDarkGreenRest);
		skp->SetPen(stdPenGreenTextDark);
	}
	skp->Rectangle(col(28), line(2), col(43), line(3));
	skp->SetTextColor(RGB(0, 0, 0));
	skp->Text(col(2), line(2), "YAW", 3);
	skp->Text(col(9), line(2), "PITCH", 5);
	skp->Text(col(20), line(2), "ROLL", 4);
	skp->Text(col(29), line(2), "ENGINE", 8);
	skp->SetTextColor(RGB(0, 100, 0));
}

void BaselandMFD::drawLineBuffer(oapi::Sketchpad *skp)
{
	for (int i = 2; i < MFDMAXLINES; i++)
	{
		try
		{
			const int x = col(1);
			const int y = line(i + 1);
			const int length = lineBuffer[i].str().length();
			string s = lineBuffer[i].str();
			
			skp->Text(x, y, s.c_str(), length);
		}
		catch (exception e)
		{
			break;
		}
	}
}

mfd_data::mfd_data(OBJHANDLE hvessel)
{
	targetModes[0] = "NO TARGET";
	targetModes[1] = "BASE";
	targetModes[2] = "NAV";
	targetModes[3] = "MANUAL";

	mainProgramModes[0] = "PROGRAM_400_HOV";
	mainProgramModes[1] = "PROGRAM_600_RET";
	mainProgramModes[2] = "PROGRAM_650_PRO";
	resetSelection();

	currentCursorLine = LINE1;
	currentBaseIndex = 0;
	currentBasePadIndex = -1;
	currentTargetMode = NO_TARGET;
	//mode = 0;
	menuemode = 1;
	this->hvessel = hvessel;
	vessel = oapiGetVesselInterface(hvessel);
}

void mfd_data::resetSelection()
{
	if (mfdi != NULL)
	{
		if (&mfdi->targetPoint != NULL)
		{
			mfdi->targetPoint.x = 0;
			mfdi->targetPoint.y = 0;
			mfdi->baseElevation = 0;
		}
	}
	currentNavSourceBase = 0;
	currentNavSourcePad = 0;
	currentBasePadIndex = -1;
}

int mfd_data::isGoForLand(NAVHANDLE nh)
{

	if (nh != NULL)
	{
		int baseIndexNavSource = -1;
		int basePadIndexNavSource = -1;

		NAVDATA nd;
		oapiGetNavData(nh, &nd);
		if (nd.type == TRANSMITTER_VTOL)
		{
			basePadIndexNavSource = nd.vtol.npad;
			for (unsigned i = 0; i<oapiGetBaseCount(vessel->GetSurfaceRef()); i++)
			{
				if (oapiGetBaseByIndex(vessel->GetSurfaceRef(), i) == nd.vtol.hBase)
				{
					baseIndexNavSource = i;
					break;
				}
			}
		}
		else return LANDING_NO_INFORMATION;
		int status = 0;
		OBJHANDLE hbase = oapiGetBaseByIndex(vessel->GetSurfaceRef(), baseIndexNavSource);
		if (hbase != NULL)
		{
			oapiGetBasePadStatus(hbase, basePadIndexNavSource, &status);
			if (status == 0)
				return LANDING_GO;
			else
				return LANDING_NO_GO;
		}
	}
	else return LANDING_NO_INFORMATION;
}

int mfd_data::isGoForLand()
{
	int status = 0;
	if (currentTargetMode == BASE)
	{
		OBJHANDLE hbase = oapiGetBaseByIndex(vessel->GetSurfaceRef(), currentBaseIndex);
		if (oapiGetBasePadStatus(hbase, currentBasePadIndex, &status))
		{
			if (hbase != NULL)
			{
				if (status == 1)
					return LANDING_NO_GO;
				else
					return LANDING_GO;
			}
			return LANDING_NO_INFORMATION;
		}
		else return LANDING_NO_INFORMATION;
	}
	else return LANDING_NO_INFORMATION;
}

int mfd_data::getModeCount()
{
	return modecount;
}

int mfd_data::getMainProgramCount()
{
	return programcount;
}

int mfd_data::getMaxLines(int tm)
{
	switch (tm)
	{
		case NO_TARGET: return 1;
		case BASE: return 3;
		case NAVSOURCE: return 3;
		case MANUAL: return 2;
	}
}

void mfd_data::incItem()
{
	switch (currentCursorLine)
	{
		case LINE1:
		{
			currentTargetMode++;
			if (currentTargetMode == getModeCount()) currentTargetMode = 0;
			resetSelection();
			break;
		}
		case LINE15:
		{
			incMainProgram();
			break;
		}
		case LINE2:
		{
			switch (currentTargetMode)
			{
				case NAVSOURCE: incNavSourceBase(); break;
				case BASE: incBase(); break;
			}
			break;
		}

		case LINE3:
		{
			switch (currentTargetMode)
			{
				case NAVSOURCE: incNavSourcePad(); break;
				case BASE: incBasePad(); break;
			}
			break;
		}
	}
}

void mfd_data::decItem()
{	
	switch (currentCursorLine)
	{
		case LINE1:
		{
			currentTargetMode--;
			if (currentTargetMode < 0) currentTargetMode = getModeCount() - 1;
			break;
		}
		case LINE15:
		{
			//DO SOMETHINK
			decMainProgram();
			break;
		}

		case LINE2:
		{
			switch (currentTargetMode)
			{
				case NAVSOURCE: decNavSourceBase(); break;
				case BASE: decBase(); break;
			}
			break;
		}
		case LINE3:
		{
			switch (currentTargetMode)
			{
				case NAVSOURCE: decNavSourcePad(); break;
				case BASE: decBasePad(); break;
			}
			break;
		}
	}

}
void mfd_data::incMainProgram()
{
	if (mfdi->masterChannel) return;
	currentMainProgramMode++;
	if (currentMainProgramMode == getMainProgramCount()) currentMainProgramMode = 0;
	updateMainProgram();
}

void mfd_data::decMainProgram()
{
	if (mfdi->masterChannel) return;
	currentMainProgramMode--;
	if (currentMainProgramMode < 0) currentMainProgramMode = getMainProgramCount() - 1;
	updateMainProgram();
}

void mfd_data::updateMainProgram()
{
	
	switch (currentMainProgramMode)
	{
		case mfd_data::mainProgramMode::PROGRAM_400_HOVER: mfdi->ptrProgram = 400;  break;
		case mfd_data::mainProgramMode::PROGRAM_600_RETRO: mfdi->ptrProgram = 600;  break;
		case mfd_data::mainProgramMode::PROGRAM_650_PRO: mfdi->ptrProgram = 650;  break;
	}
	
	switch (mfdi->ptrProgram)
	{
		case 400: mfdi->used_thgroup = THGROUP_HOVER; break;
		case 405: mfdi->used_thgroup = THGROUP_HOVER; break;
		case 410: mfdi->used_thgroup = THGROUP_HOVER; break;
		case 420: mfdi->used_thgroup = THGROUP_HOVER; break;

		case 600: mfdi->used_thgroup = THGROUP_MAIN; break;
		case 605: mfdi->used_thgroup = THGROUP_MAIN; break;
		case 610: mfdi->used_thgroup = THGROUP_MAIN; break;
		case 620: mfdi->used_thgroup = THGROUP_MAIN; break;

		case 650: mfdi->used_thgroup = THGROUP_RETRO; break;
		case 655: mfdi->used_thgroup = THGROUP_RETRO; break;
		case 660: mfdi->used_thgroup = THGROUP_RETRO; break;
		case 670: mfdi->used_thgroup = THGROUP_RETRO; break;
	}

}


void mfd_data::incBase()
{
	currentBaseIndex++;
	if (currentBaseIndex == oapiGetBaseCount(vessel->GetSurfaceRef())) currentBaseIndex = 0;
	currentBasePadIndex = -1;
}


void mfd_data::incNavSourceBase()
{
	currentNavSourceBase++;
	if (currentNavSourceBase == vessel->GetNavCount()) currentNavSourceBase = 0;
}

void mfd_data::decNavSourceBase()
{
	currentNavSourceBase--;
	if (currentNavSourceBase < 0) currentNavSourceBase = vessel->GetNavCount() - 1;
}

void mfd_data::incNavSourcePad()
{
	currentNavSourcePad++;
	if (currentNavSourcePad == vessel->GetNavCount()) currentNavSourcePad = 0;
}

void mfd_data::decNavSourcePad()
{
	currentNavSourcePad--;
	if (currentNavSourcePad < 0) currentNavSourcePad = vessel->GetNavCount() - 1;
}

void mfd_data::updateBaseDataFromNavReciever(NAVHANDLE nh)
{
	if (nh != NULL)
	{
		NAVDATA nd;
		oapiGetNavData(nh, &nd);
		if (nd.type == TRANSMITTER_VTOL)
		{
			currentBasePadIndex = nd.vtol.npad;
			for (unsigned i = 0; i<oapiGetBaseCount(vessel->GetSurfaceRef()); i++)
			{
				if (oapiGetBaseByIndex(vessel->GetSurfaceRef(), i) == nd.vtol.hBase)
				{
					currentBaseIndex = i;
					break;
				}
			}
		}
	}
}

void mfd_data::decBase()
{
	currentBaseIndex--;
	if (currentBaseIndex < 0) currentBaseIndex = oapiGetBaseCount(vessel->GetSurfaceRef()) - 1;
	currentBasePadIndex = -1;
}

void mfd_data::incLine()
{
	if (getMaxLines(currentTargetMode) > currentCursorLine) currentCursorLine++;
}

void mfd_data::decLine()
{
	if (currentCursorLine >= 1) currentCursorLine--;
}

void mfd_data::incBasePad()
{
	int basePadCount = oapiGetBasePadCount(oapiGetBaseByIndex(vessel->GetSurfaceRef(), currentBaseIndex));
	currentBasePadIndex++;
	if (currentBasePadIndex == basePadCount) currentBasePadIndex = -1;
}

void mfd_data::decBasePad()
{
	int basePadCount = oapiGetBasePadCount(oapiGetBaseByIndex(vessel->GetSurfaceRef(), currentBaseIndex));
	currentBasePadIndex--;
	if (currentBasePadIndex < -1) currentBasePadIndex = basePadCount - 1;
}

void mfd_data::updateLngLat()
{
	switch (currentTargetMode)
	{
		case BASE:
		{
			OBJHANDLE hBase = oapiGetBaseByIndex(vessel->GetSurfaceRef(), currentBaseIndex);
			if (hBase != NULL)
			{
				if (!oapiGetBasePadEquPos(hBase, currentBasePadIndex, &mfdi->targetPoint.x, &mfdi->targetPoint.y))
				{
					oapiGetBaseEquPos(hBase, &mfdi->targetPoint.x, &mfdi->targetPoint.y);
				}
				mfdi->baseElevation = oapiIsVessel(mfdi->v->GetHandle()) ? oapiSurfaceElevation(mfdi->v->GetGravityRef(), mfdi->targetPoint.x, mfdi->targetPoint.y) : 0;
			}
			break;
		}
		
		case NAVSOURCE:
		{
			NAVHANDLE nh = vessel->GetNavSource(currentNavSourcePad);
			if (nh == NULL) nh = vessel->GetNavSource(currentNavSourceBase);
			if (nh != NULL)
			{
				VECTOR3 npos;
				oapiGetNavPos(nh, &npos);
				OBJHANDLE hsurfaceref = vessel->GetSurfaceRef();
				double r = 0;
				oapiGlobalToEqu(hsurfaceref, npos, &mfdi->targetPoint.x, &mfdi->targetPoint.y, &r);
				mfdi->baseElevation = oapiIsVessel(mfdi->v->GetHandle()) ? oapiSurfaceElevation(mfdi->v->GetGravityRef(), mfdi->targetPoint.x, mfdi->targetPoint.y) : 0;
				
			}
			else
			{
				mfdi->targetPoint.x = 0;
				mfdi->targetPoint.y = 0;
				mfdi->baseElevation = 0;
			}
			break;
		}
	
	}	
	//mfdi->targetPoint.x = mfdi->menue_data->lng;
	//mfdi->targetPoint.y = mfdi->menue_data->lat;
	

}

void BaselandMFD::displayMenue(oapi::Sketchpad *skp)
{

	static const DWORD red = RGB(255, 0, 0);
	static const DWORD green = RGB(0, 255, 0);
	static const DWORD blue = RGB(110, 180, 255);
	static const DWORD grey = RGB(150, 150, 150);
	
	int fontsize = height / 20;
	int space = 4;
	int lineheight = fontsize + 2 * space;

	skp->SetTextColor(green);
	oapi::Font *f = oapiCreateFont(fontsize, true, "fixed"); // released in 1156
	
	skp->SetFont(f);

	int x = col(1);
	int tg = 0;
	int line = 1;
	
	//Creating the first line of the menue which contains the same items for all cases...
	for (int i = 0; i<mfdi->menue_data->modecount; i++)
	{
		int y = lineheight*line;
		skp->Text(x, y, mfdi->menue_data->targetModes[i].c_str(), mfdi->menue_data->targetModes[i].length());
		if (tg++ == mfdi->menue_data->currentTargetMode) markText(1, x, fontsize, space, mfdi->menue_data->targetModes[i], mfd_data::LINE1, skp);
		x += 3 * space + skp->GetTextWidth(mfdi->menue_data->targetModes[i].c_str());
	}
	int y = 0;
	{
		//Creating the second line to select the program
		line++;
		y = lineheight*line;
		x = col(1);
		//string demoText = "DEMO TEST 123456789";
		string prefix = "LANDING PROGRAM: ";			
		skp->Text(x, y, prefix.c_str(), prefix.length());
		x += skp->GetTextWidth(prefix.c_str());
		skp->Text(x, y, mfdi->menue_data->mainProgramModes[mfdi->menue_data->currentMainProgramMode].c_str(), mfdi->menue_data->mainProgramModes[mfdi->menue_data->currentMainProgramMode].length());
		markText(line, x, fontsize, space, mfdi->menue_data->mainProgramModes[mfdi->menue_data->currentMainProgramMode], mfd_data::LINE15, skp);
		
	}

	line ++;
	y = lineheight*line;
	x = col(1);
	
	//The item of the second line is depending on the item selected in the first line, so we need a swicht here...	
	switch (mfdi->menue_data->currentTargetMode)
	{
		case mfd_data::BASE:
		{
			skp->Text(x, y, "BASE:", 5);
			x += skp->GetTextWidth("BASE:") + 6 * space;
			oapiGetFocusInterface()->GetSurfaceRef();
			char basename[255];
			OBJHANDLE hBase = oapiGetBaseByIndex(oapiGetFocusInterface()->GetSurfaceRef(), mfdi->menue_data->currentBaseIndex);
			if (hBase != NULL)
			{
				oapiGetObjectName(hBase, basename, 255);
				string str_basename(basename);
				skp->Text(x, y, str_basename.c_str(), str_basename.length());
				markText(line, x, fontsize, space, str_basename, mfd_data::LINE2, skp);
				line++;
				y = lineheight*line;
				x = col(1);
				skp->Text(x, y, "PAD:", 4);
				x += 6 * space + skp->GetTextWidth("PAD:");
				int padCount = oapiGetBasePadCount(oapiGetBaseByIndex(oapiGetFocusInterface()->GetSurfaceRef(), mfdi->menue_data->currentBaseIndex));

				//Draw the first option to select no basepad which is "-"
				skp->SetTextColor(blue);
				skp->Text(x, y, "B", 1);
				if (mfdi->menue_data->currentBasePadIndex == -1) markText(line, x, fontsize, space, "D", mfd_data::LINE3, skp);
				
				x += skp->GetTextWidth("D") + space;

				for (int i = 0; i < padCount; i++)
				{
					int padStatus;
					oapiGetBasePadStatus(hBase, i, &padStatus);

					if (padStatus == 1) skp->SetTextColor(red);
					else skp->SetTextColor(green);

					stringstream basePadName;
					basePadName << i + 1;
					skp->Text(x, y, basePadName.str().c_str(), basePadName.str().length());
					if (i == mfdi->menue_data->currentBasePadIndex) markText(line, x, fontsize, space, basePadName.str(), mfd_data::LINE3, skp);
					x += skp->GetTextWidth(basePadName.str().c_str()) + space;
				}
			}
			break;
		}
		
		case mfd_data::NAVSOURCE:
		{
			skp->Text(x, y, "BASE NAV:", 11);
			x += 6 * space + skp->GetTextWidth("BASE NAV:");
			NAVHANDLE nhBase;
			for (unsigned i = 0; i<oapiGetFocusInterface()->GetNavCount(); i++)
			{
				nhBase = oapiGetFocusInterface()->GetNavSource(i);
				stringstream navNr("");
				navNr << i + 1;
				if (nhBase == NULL) skp->SetTextColor(grey);
				else
				{
					if (mfdi->menue_data->isGoForLand(nhBase) == mfd_data::LANDING_NO_GO) skp->SetTextColor(red);
					else if (mfdi->menue_data->isGoForLand(nhBase) == mfd_data::LANDING_GO) skp->SetTextColor(green);
					else skp->SetTextColor(blue);
				}
				skp->Text(x, y, navNr.str().c_str(), navNr.str().length());
				if (i == mfdi->menue_data->currentNavSourceBase) markText(line, x, fontsize, space, navNr.str(), mfd_data::LINE2, skp);
				x += skp->GetTextWidth(navNr.str().c_str());
				x += skp->GetTextWidth(" ");
			}
			nhBase = oapiGetFocusInterface()->GetNavSource(mfdi->menue_data->currentNavSourceBase);
			if (nhBase != NULL)
			{
				line ++;
				y = lineheight*line;
				x = col(1);
				skp->SetTextColor(blue);
				char navdesc[255];
				oapiGetNavDescr(nhBase, navdesc, 255);
				stringstream transppnder_id("");
				transppnder_id << "ID: " << navdesc;
				skp->Text(x, y, transppnder_id.str().c_str(), transppnder_id.str().length());
			}

			x = col(1);
			skp->SetTextColor(green);
			line=6;
			y = lineheight*line;

			skp->Text(x, y, "PAD NAV:", 11);
			x += 6 * space + skp->GetTextWidth("PAD NAV:");

			NAVHANDLE nhPad;
			for (unsigned i = 0; i<oapiGetFocusInterface()->GetNavCount(); i++)
			{
				nhPad = oapiGetFocusInterface()->GetNavSource(i);
				stringstream navNr("");
				navNr << i + 1;
				if (nhPad == NULL) skp->SetTextColor(grey);
				else
				{
					if (mfdi->menue_data->isGoForLand(nhPad) == mfd_data::LANDING_NO_GO) skp->SetTextColor(red);
					else if (mfdi->menue_data->isGoForLand(nhPad) == mfd_data::LANDING_GO) skp->SetTextColor(green);
					else skp->SetTextColor(blue);
				}
				skp->Text(x, y, navNr.str().c_str(), navNr.str().length());
				if (i == mfdi->menue_data->currentNavSourcePad) markText(line, x, fontsize, space, navNr.str(), mfd_data::LINE3, skp);
				x += skp->GetTextWidth(navNr.str().c_str());
				x += skp->GetTextWidth(" ");
			}
			nhPad = oapiGetFocusInterface()->GetNavSource(mfdi->menue_data->currentNavSourcePad);
			if (nhPad != NULL)
			{
				line++;
				y = lineheight*line;
				x = col(1);
				skp->SetTextColor(blue);
				char navdesc[255];
				oapiGetNavDescr(nhPad, navdesc, 255);
				stringstream transppnder_id("");
				transppnder_id << "ID: " << navdesc;
				skp->Text(x, y, transppnder_id.str().c_str(), transppnder_id.str().length());
			}
			break;
		}
		
		case mfd_data::MANUAL:
		{
			string lbl_Enter = "ENTER MANUALY";
			skp->Text(x, y, lbl_Enter.c_str(), lbl_Enter.length());
			markText(line, x, fontsize, space, lbl_Enter, mfd_data::LINE2, skp);
			//mfdi->menue_data->currentCursorLine = mfd_data::LINE1;
			break;
		}
	}
	if (mfdi->menue_data->currentTargetMode != mfd_data::NO_TARGET)
	{
		// Draw lng / lat on the buttom of the menue
		string latLbl = "LAT:";
		string lngLbl = "LNG:";
		string elevationLbl = "ELV:";
		string bearingLbl = "BRG:";
		stringstream latString("");
		stringstream lngString("");
		stringstream elevationString("");
		stringstream bearingString("");

		char noso = 'N';
		char eswe = 'E';

		if (mfdi->targetPoint.x < 0) eswe = 'W';
		if (mfdi->targetPoint.y < 0) noso = 'S';

		lngString << fabs(mfdi->targetPoint.x * 180 / PI) << "°" << eswe;
		latString << fabs(mfdi->targetPoint.y * 180 / PI) << "°" << noso;	
		elevationString << mfdi->baseElevation << "m";
		bearingString << MYMATH::getDirAbs(mfdi->v, mfdi->targetPoint.y, mfdi->targetPoint.x) toDeg << "°";
		

		if (mfdi->menue_data->currentTargetMode != mfd_data::MANUAL) skp->SetTextColor(blue);
		x = col(1);
		line = 9;
		y = lineheight*line;


		skp->Text(x, y, latLbl.c_str(), latLbl.length());
		x += 6 * space + skp->GetTextWidth(latLbl.c_str());
		skp->Text(x, y, latString.str().c_str(), latString.str().length());

		line++;

		y = lineheight*line;
		x = col(1);
		skp->Text(x, y, lngLbl.c_str(), lngLbl.length());
		x += 6 * space + skp->GetTextWidth(lngLbl.c_str());
		skp->Text(x, y, lngString.str().c_str(), lngString.str().length());


		line++;

		y = lineheight*line;
		x = col(1);
		skp->Text(x, y, elevationLbl.c_str(), elevationLbl.length());
		x += 6 * space + skp->GetTextWidth(elevationLbl.c_str());
		skp->Text(x, y, elevationString.str().c_str(), elevationString.str().length());

		line++;

		y = lineheight*line;
		x = col(1);
		skp->Text(x, y, bearingLbl.c_str(), bearingLbl.length());
		x += 6 * space + skp->GetTextWidth(bearingLbl.c_str());
		skp->Text(x, y, bearingString.str().c_str(), bearingString.str().length());


		//sprintf(oapiDebugString(), "%f %f %f", MYMATH::getDirAbs(mfdi->v, mfdi->targetPoint.y, mfdi->targetPoint.x) toDeg, mfdi->targetPoint.y, mfdi->targetPoint.x);


	}
	oapiReleaseFont(f);
}

void BaselandMFD::markText(int line, int x, int fontsize, int space, string text, int linemode, oapi::Sketchpad *skp)
{
	//oapi::Pen *stdPenGreen2 = oapiCreatePen(1, 3, RGB(0, 255, 0));  //released in 1178
	//oapi::Pen *stdPenGreen = oapiCreatePen(1, 1, RGB(0, 100, 0));  //released in 1179
	
	if (mfdi->menue_data->currentCursorLine == linemode)
	{
		skp->SetPen(stdPenGreenTextLight);
	}
	else
	{
		skp->SetPen(stdPenGreenTextDark);
	}
	int lineheight = fontsize + 2 * space;
	int x0 = x - space / 2;
	int x1 = x + skp->GetTextWidth(text.c_str(), text.length()) + space / 2;
	int y0 = line * lineheight + space / 2;
	int y1 = line * lineheight + lineheight - space * 2;
	
	//skp->SetBrush(NULL);
	skp->Rectangle(x0, y0, x1, y1);
	
	//oapiReleasePen(stdPenGreen2);
	//oapiReleasePen(stdPenGreen);
}
/*
void SurfaceSpeedMFD::WriteStatus(FILEHANDLE scn) const
{
	for (int i = 0; i < autopilots.size(); i++)
	{
		stringstream sProgramm;
		sProgramm << "PROGRAMM[" << i << "]";
		char* cProgramm = (char*)sProgramm.str().c_str();


		oapiWriteScenario_int(scn, cProgramm, autopilots.at(i)->ptrProgram);
		oapiWriteScenario_vec(scn, c, autopilots.at(i)->targetPoint);
		oapiWriteScenario_int(scn, c, autopilots.at(i)->menue_data->currentBaseIndex);
		oapiWriteScenario_int(scn, c, autopilots.at(i)->menue_data->currentBasePadIndex);
	}
	//oapiWriteScenario_int(scn, "PROGRAM", mfdi->ptrProgram);
	//oapiWriteScenario_vec(scn, "TARGETPOINT", mfdi->targetPoint);
	//oapiWriteScenario_int(scn, "TARGETBASEINDEX",mfdi->menue_data->currentBaseIndex);
	//oapiWriteScenario_int(scn, "TARGETBASEPADINDEX", mfdi->menue_data->currentBaseIndex);	
}

void SurfaceSpeedMFD::ReadStatus(FILEHANDLE scn)
{
	/*
	char* line = new char[255];
	while (oapiReadScenario_nextline(scn, line))
	{
		if (!_strnicmp(line, "PROGRAM", 7))
		{
			int val;
			sscanf(line + 7, "%i", &val);
			//mfdi->ptrProgram = val;
			//sprintf(oapiDebugString(),"%i", val);
		}
	}
	delete line;
	
}
*/

bool /*SurfaceSpeedMFD::*/inputData(void *id, char *str, void *usrdata)
{
	BaselandMFD* surfaceSpeedMFD = (BaselandMFD*)usrdata;
	double lat;
	double lng;
	if (sscanf(str, "%lf %lf", &lat, &lng) != 2)
	{
		return false;
	}

	mfdi->targetPoint.x = lng * (PI / 180);
	mfdi->targetPoint.y = lat * (PI / 180);
	mfdi->baseElevation = oapiIsVessel(mfdi->v->GetHandle()) ? oapiSurfaceElevation(mfdi->v->GetGravityRef(), mfdi->targetPoint.x, mfdi->targetPoint.y) : 0;
	
	mfdi->menue_data->currentTargetMode = mfdi->menue_data->MANUAL;	
	return true;
}