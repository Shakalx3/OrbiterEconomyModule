#define STRICT
#define ORBITER_MODULE
#include "includes.h"

#define STRICT
int mode;

class Mymod : public oapi::Module 
{
	public:
		Mymod (HINSTANCE hDLL): Module (hDLL) {}
		void clbkPreStep(double simt,double simdt,double mjd);
		void clbkPostStep(double simt,double simdt,double mjd);
		void clbkSimulationStart(oapi::Module::RenderMode mode);
		void clbkSimulationEnd();
		void clbkDeleteVessel(OBJHANDLE vessel);
		void clbkNewVessel(OBJHANDLE vessel);
		
	//private:
		//void checkWaypointReached(unsigned int currentIndex);
		//void getGearAlt(VESSEL* vessel);
};

std::vector<autopilot*> autopilots;

Mymod *mymod;

/*
// DONT DELETE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void Mymod::getGearAlt(VESSEL* vessel)
{
	//this->gd = mfdh.getVesselData(oapiGetFocusInterface()->GetHandle());
	VECTOR3 tpl[3],tpg[3];		
	double lng,lat,rmin=DBL_MAX,rmax=DBL_MIN;
	oapiGetFocusInterface()->GetTouchdownPoints(tpl[0],tpl[1],tpl[2]);
	for (int i=0;i<3;i++)
	{
		double r=0;
		oapiLocalToGlobal(oapiGetFocusInterface()->GetHandle(),tpl+i,tpg+i);
		oapiGlobalToEqu(oapiGetFocusInterface()->GetSurfaceRef(),tpg[i],&lng,&lat,&r);
		//r = r - oapiGetSize(oapiGetFocusInterface()->GetSurfaceRef());
		if(r>rmax) rmax=r;
		if(r<rmin) rmin=r;
	}
	if (oapiGetFocusInterface()->GetFlightStatus() == 1)  mfdh.getVesselData(oapiGetFocusInterface()->GetHandle())->gearAlt = 0;
	else  mfdh.getVesselData(oapiGetFocusInterface()->GetHandle())->gearAlt = rmin - oapiGetSize(oapiGetFocusInterface()->GetSurfaceRef());
}
*/

struct loadState
{
	int index;
	int ptrProgram;
	int masterChannel;
	int yawChannel;
	int pitchChannel;
	int rollChannel;
	int vaChannel;
	int currentBaseIndex;
	int currentBasePadIndex;

	int currentCursorLine;
	int currentNavSourceBase;
	int currentNavSourcePad;
	int currentTargetMode;
	
	double terrainScanPtr;
	double maxElevation;
	double distanceToMaxElevationFromBase;
	//double distanceToMaxElevation;

	int menuemode;
	VECTOR3 targetPoint;
	VECTOR3 deltaAngularVelOld;
	VECTOR3 ypr_setpoint;
};

std::vector<loadState*> loadStates;
double dtPre = 0;
void Mymod:: clbkPreStep(double simt,double simdt,double mjd)
{
	//dtPre = simdt;
}

void Mymod::clbkPostStep(double simt,double simdt,double mjd)
{
	dtPre = simdt;
	for (unsigned i = 0; i < autopilots.size(); i++)
	{
		autopilot *ap = autopilots.at(i);	
		ap->maincontroll();
	}
	
	if(GetAsyncKeyState(VK_NUMPAD1))
	{
		int i = 0;
	}
}

void Mymod::clbkSimulationStart(oapi::Module::RenderMode rmode)
{
	//loadStates.size();

	for (unsigned i = 0; i < oapiGetVesselCount(); i++)
	{
		autopilot *ap = new autopilot(oapiGetVesselInterface(oapiGetVesselByIndex(i)));
		if (loadStates.size() > 0)
		{
				
			loadState *ls = loadStates.at(i);
				
				
			ap->ptrProgram = ls->ptrProgram;
			ap->targetPoint = ls->targetPoint;
			ap->baseElevation = oapiIsVessel(ap->v->GetHandle()) ? oapiSurfaceElevation(ap->v->GetGravityRef(), ap->targetPoint.x, ap->targetPoint.y) : 0;
			ap->ypr_setpoint = ls->ypr_setpoint;
			ap->menue_data->menuemode = ls->menuemode;
			ap->menue_data->currentCursorLine = ls->currentCursorLine;
			ap->menue_data->currentNavSourceBase = ls->currentNavSourceBase;
			ap->menue_data->currentNavSourcePad = ls->currentNavSourcePad;
			ap->menue_data->currentTargetMode = ls->currentTargetMode;
			ap->menue_data->currentBaseIndex = ls->currentBaseIndex;
			ap->menue_data->currentBasePadIndex = ls->currentBasePadIndex;
			ap->masterChannel = ls->masterChannel == 1;
			ap->pitchChannel = ls->pitchChannel == 1;
			ap->rollChannel = ls->rollChannel == 1;
			ap->yawChannel = ls->yawChannel == 1;
			ap->vaChannel = ls->vaChannel == 1;

			//ap->terrainScanPtr = ls->terrainScanPtr;
			ap->maxElevation = ls->maxElevation;
			ap->distanceToMaxElevationFromBase = ls->distanceToMaxElevationFromBase;
			//ap->distanceToMaxElevation = ls->distanceToMaxElevation;


			switch (ap->ptrProgram)
			{
			case 400: ap->used_thgroup = THGROUP_HOVER; break;
			case 405: ap->used_thgroup = THGROUP_HOVER; break;
			case 410: ap->used_thgroup = THGROUP_HOVER; break;
			case 420: ap->used_thgroup = THGROUP_HOVER; break;

			case 600: ap->used_thgroup = THGROUP_MAIN; break;
			case 605: ap->used_thgroup = THGROUP_MAIN; break;
			case 610: ap->used_thgroup = THGROUP_MAIN; break;
			case 620: ap->used_thgroup = THGROUP_MAIN; break;

			case 650: ap->used_thgroup = THGROUP_RETRO; break;
			case 655: ap->used_thgroup = THGROUP_RETRO; break;
			case 660: ap->used_thgroup = THGROUP_RETRO; break;
			case 670: ap->used_thgroup = THGROUP_RETRO; break;
			}
		}
		autopilots.push_back(ap);
	}
	
}

void Mymod::clbkSimulationEnd()
{
	for (unsigned i = 0; i < autopilots.size(); i++) delete autopilots.at(i);
	autopilots.clear();
	for (unsigned i = 0; i < oapiGetVesselCount(); i++)
		delete autopilots.at(i);
	autopilots.clear();
	

	for (int i = 0; i < loadStates.size(); i++)
		delete loadStates[i];
	loadStates.clear();
}

void Mymod::clbkDeleteVessel(OBJHANDLE ohvessel)
{
	unsigned i = 0;
	for (i; i < oapiGetVesselCount(); i++)
		if (autopilots.at(i)->menue_data->hvessel == ohvessel)
			break;
	delete autopilots.at(i);
	autopilots.erase(autopilots.begin() + i);
}

void Mymod::clbkNewVessel(OBJHANDLE ohvessel)
{
	autopilot *ap = new autopilot(oapiGetVesselInterface(ohvessel));
	autopilots.push_back(ap);
}

DLLCLBK void InitModule (HINSTANCE hDLL)
{	
	static char *name = "BaseLandAutopilot";
	MFDMODESPECEX spec;
	spec.name    = name;
	spec.key     = OAPI_KEY_U;
	spec.context = NULL;
	spec.msgproc = BaselandMFD::MsgProc;
	mode = oapiRegisterMFDMode (spec);
	mymod = new Mymod (hDLL);
	
	oapiRegisterModule (mymod);
}

DLLCLBK void ExitModule (HINSTANCE hDLL)
{
	//delete mymod not required;
}

//DLL- Unregister
DLLCLBK void opcDLLExit (HINSTANCE hDLL)
{
   oapiUnregisterMFDMode (mode);
}

char* getItemString(char* item, int index)
{
	stringstream sProgramm("");
	sProgramm << item << "["<< index  << "]";
	string s = sProgramm.str();
	char* c = strdup(s.c_str());
	return c;
}

int scan_int(string var, int index, char* scnLine, int *out)
{
	
	var += "[";
	char buffer[16];
	string str_number = itoa(index, buffer, 10);
	var += str_number;
	var += "]";
	char* line = strdup(var.c_str());
	if (!_strnicmp(scnLine, var.c_str(), var.length() ))
	{
		int val = -1;
		sscanf(scnLine + var.length(), "%i", &val);
		*out = val;
		return true;
	}
	return false;
}

bool scan_v3(string var, int index, char* scnLine, VECTOR3* v3)
{
	var += "[";
	char buffer[16];
	string str_number = itoa(index, buffer, 10);
	var += str_number;
	var += "]";
	char* line = strdup(var.c_str());
	if (!_strnicmp(scnLine, var.c_str(), var.length()))
	{
		if (index == 1)
		{
			int bla = 0;
		}
		float valx = -1, valy = -1, valz = -1;
		sscanf(scnLine + var.length(), "%f %f %f", &valx, &valy, &valz);
		v3->x = valx;
		v3->y = valy;
		v3->z = valz;
		return true;
	}
	return false;
}
int scan_float(string var, int index, char* scnLine, float *out)
{

	var += "[";
	char buffer[16];
	string str_number = itoa(index, buffer, 10);
	var += str_number;
	var += "]";
	char* line = strdup(var.c_str());
	if (!_strnicmp(scnLine, var.c_str(), var.length()))
	{
		float val = -1;
		sscanf(scnLine + var.length(), "%f", &val);
		*out = val;
		return true;
	}
	return false;
}

DLLCLBK void opcSaveState(FILEHANDLE scn) 
{
	for (int i = 0; i < autopilots.size(); i++)
	{
		autopilot *ap = autopilots.at(i);
		oapiWriteScenario_int(scn, getItemString("PROGRAM", i), ap->ptrProgram);
		oapiWriteScenario_vec(scn, getItemString("TARGETPOINT", i), ap->targetPoint);
		oapiWriteScenario_int(scn, getItemString("BASEINDEX", i), ap->menue_data->currentBaseIndex);
		oapiWriteScenario_int(scn, getItemString("BASEPADINDEX", i), ap->menue_data->currentBasePadIndex);
		oapiWriteScenario_int(scn, getItemString("MASTERCHANNEL", i), ap->masterChannel ? 1 : 0);
		oapiWriteScenario_int(scn, getItemString("ROLLCHANNEL", i), ap->rollChannel ? 1 : 0);
		oapiWriteScenario_int(scn, getItemString("PITCHCHANNEL", i), ap->pitchChannel ? 1 : 0);
		oapiWriteScenario_int(scn, getItemString("YAWCHANNEL", i), ap->yawChannel ? 1 : 0);
		oapiWriteScenario_int(scn, getItemString("ENGINECHANNEL", i), ap->vaChannel ? 1 : 0);
		oapiWriteScenario_int(scn, getItemString("MENUEMODE", i), ap->menue_data->menuemode);
		oapiWriteScenario_int(scn, getItemString("CURRENTCURSORLINE", i), ap->menue_data->currentCursorLine);
		oapiWriteScenario_int(scn, getItemString("CURRENTNAVSOURCEBASE", i), ap->menue_data->currentNavSourceBase);
		oapiWriteScenario_int(scn, getItemString("CURRENTNAVSOURCEPAD", i), ap->menue_data->currentNavSourcePad);
		oapiWriteScenario_int(scn, getItemString("CURRENTTARGETMODE", i), ap->menue_data->currentTargetMode);
		oapiWriteScenario_vec(scn, getItemString("DELTAANGULARVELOLD", i), ap->deltaAngularVelOld);
		oapiWriteScenario_vec(scn, getItemString("YPR_SETPOINT", i), ap->ypr_setpoint);

		//oapiWriteScenario_float(scn, getItemString("TERRAINSCANPTR", i), ap->terrainScanPtr);
		oapiWriteScenario_float(scn, getItemString("MAXELEVATION", i), ap->maxElevation);
		oapiWriteScenario_float(scn, getItemString("DISTTOMAXELVFROMBASE", i), ap->distanceToMaxElevationFromBase);
		//oapiWriteScenario_float(scn, getItemString("DISTTOMAXELV", i), ap->distanceToMaxElevation);
		

		//double terrainScanPtr;
		//double maxElevation;
		//double distanceToMaxElevationFromBase;
		
	}	
}


DLLCLBK void opcLoadState(FILEHANDLE scn) 
{
	char* line;
	while (oapiReadScenario_nextline(scn, line))
	{
		string str = string(line);
		for (int i = 0; i < 10; i++)
		{
			loadState *ls = NULL;
			bool found = false;
			for (int ils = 0; ils < loadStates.size(); ils++)
			{
				if (loadStates.at(ils)->index == i)
				{
					ls = loadStates.at(ils);
					break;
				}
			}
			if (ls == NULL)
			{
				ls = new loadState;
				ls->index = i;
				loadStates.push_back(ls);
			}

			int val1;
			if (scan_int("PROGRAM", i, line, &val1))
			{
				ls->ptrProgram = val1;
			}

			int val2;
			if (scan_int("BASEINDEX", i, line, &val2))
			{
				ls->currentBaseIndex = val2;
			}
			int val3;
			if (scan_int("BASEPADINDEX", i, line, &val3))
			{
				ls->currentBasePadIndex = val3;
			}
			int val4;
			if (scan_int("MASTERCHANNEL", i, line, &val4))
			{
				ls->masterChannel = val4;
			}			
			int val5;
			if (scan_int("ROLLCHANNEL", i, line, &val5))
			{
				ls->rollChannel = val5;
			}
			int val6;
			if (scan_int("PITCHCHANNEL", i, line, &val6))
			{
				ls->pitchChannel = val6;
			}
			int val7;
			if (scan_int("YAWCHANNEL", i, line, &val7))
			{
				ls->yawChannel = val7;
			}
			int val8;
			if (scan_int("ENGINECHANNEL", i, line, &val8))
			{
				ls->vaChannel = val8;
			}

			int val9;
			if (scan_int("MENUEMODE", i, line, &val9))
			{
				ls->menuemode = val9;
			}

			int val10;
			if (scan_int("CURRENTCURSORLINE", i, line, &val10))
			{
				ls->currentCursorLine = val10;
			}

			int val11;
			if (scan_int("CURRENTNAVSOURCEBASE", i, line, &val11))
			{
				ls->currentNavSourceBase = val11;
			}

			int val12;
			if (scan_int("CURRENTNAVSOURCEPAD", i, line, &val12))
			{
				ls->currentNavSourcePad = val12;
			}
			int val13;
			if (scan_int("CURRENTTARGETMODE", i, line, &val13))
			{
				ls->currentTargetMode = val13;
			}

			VECTOR3 v31 = {0,0,0};
			if (scan_v3("TARGETPOINT", i, line, &v31))
			{
				ls->targetPoint = v31;
			}
			VECTOR3 v32 = { 0,0,0 };
			if (scan_v3("DELTAANGULARVELOLD", i, line, &v32))
			{
				ls->deltaAngularVelOld = v32;
			}			
			VECTOR3 v33 = { 0,0,0 };
			if (scan_v3("YPR_SETPOINT", i, line,&v33))
			{
				ls->ypr_setpoint = v33;
			}

			
			//float d01;
			//if (scan_float("TERRAINSCANPTR", i, line, &d01))
			//{
			//	ls->terrainScanPtr = d01;
			//}
			
			float d02;
			if (scan_float("MAXELEVATION", i, line, &d02))
			{
				ls->maxElevation = d02;
			}

			float d03;
			if (scan_float("DISTTOMAXELVFROMBASE", i, line, &d03))
			{
				ls->distanceToMaxElevationFromBase = d03;
			}
			/*
			float d04;
			if (scan_float("DISTTOMAXELV", i, line, &d04))
			{
				ls->distanceToMaxElevation = d04;
			}
			*/
		}
	}
}

