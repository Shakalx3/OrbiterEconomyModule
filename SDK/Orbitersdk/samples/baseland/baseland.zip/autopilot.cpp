#include "includes.h"


void autopilot::setProgram(int ptrProgram)
{
	resetThruster();
	oapiSetTimeAcceleration(1);
	this->ptrProgram = ptrProgram;
}

//Returns the saveti altitude, on witch the hove engines can stop the vessel before hiting the ground. (Always on the current speed of the vessel)
double autopilot::getSaveAlt(VESSEL* VLAP, double offset)
{
	VECTOR3 vG;
	VLAP->GetWeightVector(vG);
	double FDown = sqrt((vG.x*vG.x) + (vG.y*vG.y) + (vG.z*vG.z));
	double aDown = FDown / VLAP->GetMass(); //acceleration down
	int nthr = VLAP->GetGroupThrusterCount(THGROUP_HOVER);
	double FupMax = 0;
	for (int i = 0; i<nthr; i++)
	{
		THRUSTER_HANDLE th = VLAP->GetGroupThruster(THGROUP_HOVER, i);
		FupMax = FupMax + VLAP->GetThrusterMax0(th);
	}
	double aUpMax = FupMax / VLAP->GetMass();
	double aTot = aUpMax - aDown;
	double Alt = (VLAP->GetAltitude(AltitudeMode::ALTMODE_GROUND) - offset) * 0.5;
	VECTOR3 Vspd;
	VLAP->GetHorizonAirspeedVector(Vspd);
	double Yspd = Vspd.y;
	double S = (((Yspd*Yspd) / 2) / aTot) * 1.00; //20% reserve
	double thSaveAlt = 0;
	if (S>(Alt)) thSaveAlt = 0.2 * (thSaveAlt + (sqrt(fabs(S - Alt))));
	if (S<(Alt)) thSaveAlt = 0.2 * (thSaveAlt - (sqrt(fabs(S - Alt))));
	return thSaveAlt;
}

autopilot::~autopilot()
{
	
	delete menue_data;
}


bool autopilot::GetOffsetToBase()
{
	VECTOR3 global_pos, local_pos;
	double r_g = oapiGetSize(v->GetGravityRef()); // v = oapiGetFocusInterface()
	double r_deg = oapiOrthodome(pos.x,pos.y,targetPoint.x, targetPoint.y);	
	if (r_deg > r_degLast && distanceToBasePad > 100) // TODO: autopilot goes crazy without >100???
	{
		r_deg = PI2 - r_deg;
	}
	r_degLast = oapiOrthodome(pos.x, pos.y, targetPoint.x, targetPoint.y);

	oapiEquToGlobal (v->GetGravityRef(), targetPoint.x, targetPoint.y, r_g, &global_pos);
	v->Global2Local (global_pos, local_pos); // Convert global frame to local		
	v->HorizonRot(local_pos,deltaPos); //Performce a rotation to get horizontal offset and North is pointing into z direction
	double heading;
	oapiGetHeading(v->GetHandle(),&heading);	
	double x, z;
	//Performce a 2D rotation so that nose is pointing into z direction
	x =  deltaPos.x * cos(-heading) - deltaPos.z * sin(heading);
	z = -deltaPos.x * sin(-heading) + deltaPos.z * cos(heading);
	deltaPos.x = x;
	deltaPos.z = z;
	/*
	if (v->GetHandle() == oapiGetFocusObject())
		sprintf(oapiDebugString(), "%f   %f", r_deg, distanceToBasePad);
		*/
	distanceToBasePad = r_deg * r_g;	//Distance to target in m


	return true;
}

bool print = false;

void autopilot::updateData()
{		
	v->GetEquPos(pos.x,pos.y,pos.z);
	GetOffsetToBase();
	v->GetHorizonAirspeedVector(horizonAirspeedVector);
	HorizontalSpeed = sqrt((horizonAirspeedVector.x*horizonAirspeedVector.x) + (horizonAirspeedVector.z * horizonAirspeedVector.z));	
	VECTOR3 groundSpeedVector;
	v->GetGroundspeedVector(FRAME_HORIZON, groundSpeedVector);
	distanceToInterceptPont = distanceToBasePad - interceptPoint;
	
	double currentAirSpeedUp2 = HorizontalSpeed * HorizontalSpeed;	
	requiredHorizontalAccelerationToBase =			 -currentAirSpeedUp2 / (1.975 * distanceToBasePad);
	requiredHorizontalAccelerationToInterceptPoint = -currentAirSpeedUp2 / (1.975 * distanceToInterceptPont);

	horizontalSpeedVectorHeading = ORBITERTOOLS::getFlightVectorHeading(v);	
	altOverGround = v->GetAltitude(AltitudeMode::ALTMODE_GROUND) - getGearAlt(v);
	if (distanceToMaxElevationFromBase >= 0) distanceToMaxElevation = distanceToBasePad - distanceToMaxElevationFromBase;
	//else distanceToMaxElevation = distanceToBasePad;
	if (distanceToBasePadOld > distanceToBasePad)
	{
		closingBase = true;
	}
	else
	{
		closingBase = false;
	}
	distanceToBasePadOld = distanceToBasePad;
	a_groundspeed = (groundSpeedVector - v_groundspdold) / oapiGetSimStep();
	v_groundspdold = groundSpeedVector;
	rAltMaxElevation = getAltitudeAtDistance(distanceToMaxElevation);
	rAltBase = getAltitudeAtDistance(distanceToBasePad);

}

double autopilot::getRequiredVerticalAcceleration(double interceptAlt)	//VERTICAL ACCELERATION PROGRAMM
{
	double t = (distanceToMaxElevation * 2) / (HorizontalSpeed);  // Time to the point with maximum elevation angle
	double k1 = 0.65;
	double k2 = -7;
	double dh = v->GetAltitude(AltitudeMode::ALTMODE_MEANRAD) - maxElevation - interceptAlt; //Current delta between altitude and maximum elevation
	return k2 * (k1 * t * horizonAirspeedVector.y + dh) / (t*t);
}

//double autopilot::getRequiredVerticalAcceleration(double interceptAlt)	//VERTICAL ACCELERATION PROGRAMM
//{
//	double minAlt = -min(rAltBase, rAltMaxElevation) + interceptAlt;
//
//	double t = (distanceToMaxElevation * 2) / (HorizontalSpeed);  // Time to the point with maximum elevation angle
//	double k1 = 0.65;
//	double k2 = -7;
//	double dh = v->GetAltitude(AltitudeMode::ALTMODE_MEANRAD) - maxElevation - interceptAlt; //Current delta between altitude and maximum elevation
//	return k2 * (k1 * t * horizonAirspeedVector.y + dh - (minAlt * 0.25)) / (t*t);
//}

double autopilot::getRequiredVerticalAccelerationBase(double interceptAlt)	//VERTICAL ACCELERATION PROGRAMM
{
	double t = (distanceToBasePad * 2) / (HorizontalSpeed);  // Time to the point with maximum elevation angle
	double k1 = 0.65;
	double k2 = -7;
	double dh = v->GetAltitude(AltitudeMode::ALTMODE_MEANRAD) - baseElevation - interceptAlt; //Current delta between altitude and maximum elevation
	return k2 * (k1 * t * horizonAirspeedVector.y + dh) / (t*t);
}


double autopilot::getRequiredVerticalAccelerationMain(double interceptAlt)	//VERTICAL ACCELERATION PROGRAMM
{
	double t = (distanceToMaxElevation * 2) / (HorizontalSpeed);  // Time to the point with maximum elevation angle
	double k1 = 0.62;
	double k2 = -6.5;
	double dh = v->GetAltitude(AltitudeMode::ALTMODE_MEANRAD) - maxElevation - interceptAlt; //Current delta between altitude and maximum elevation
	return  k2 * (k1 * t * horizonAirspeedVector.y + dh) / (t*t);
}

void autopilot::program400()	// Wait for acceleration (No braking), no RCS
{
	double pitch;
	double aHorz = requiredHorizontalAccelerationToInterceptPoint;
	double aVert = getRequiredVerticalAcceleration(inteceptAlt);
	setPitchAndEngineLevelForAccelerations(aHorz, aVert, used_thgroup, pitch, engineLevel);
	ypr_setpoint.y = pitch;
	if (engineLevel > 0.5) setProgram(405);	
}
void autopilot::program600()	// Wait for acceleration (No braking), no RCS
{
	double pitch;
	double aHorz = requiredHorizontalAccelerationToInterceptPoint;
	double aVert = getRequiredVerticalAcceleration(inteceptAlt);
	setPitchAndEngineLevelForAccelerations(aHorz, aVert, used_thgroup, pitch, engineLevel);
	ypr_setpoint.z = 0;
	if (engineLevel > 0.5) setProgram(605);	
}

void autopilot::program650()	// Wait for acceleration (No braking), no RCS
{
	
	double pitch;
	double aHorz = requiredHorizontalAccelerationToInterceptPoint;
	double aVert = getRequiredVerticalAcceleration(inteceptAlt);
	setPitchAndEngineLevelForAccelerations(aHorz, aVert, used_thgroup, pitch, engineLevel);

	//sprintf(oapiDebugString(), "Engine Level: %f", engineLevel);
	ypr_setpoint.z = 0;
	if (engineLevel > 0.5) setProgram(655);
}

void autopilot::program405()	// Wait for acceleration (No braking) (Hover Engine Mode)
{
	program300(); //YAW PROGRAMM
	program310(); //BANK PROGRAMM I
	double pitch;
	double aHorz = requiredHorizontalAccelerationToInterceptPoint;
	double aVert = getRequiredVerticalAcceleration(inteceptAlt);
	setPitchAndEngineLevelForAccelerations(aHorz, aVert, used_thgroup, pitch, engineLevel);
	ypr_setpoint.y = pitch;
	if (engineLevel > getEngineLevelForIgnition()) setProgram(410);
}

void autopilot::program605()	//Wait for acceleration (No braking) RCS and RADAR (Main Engine Program)
{
	program700(); //YAW PROGRAMM
	program710(); //BANK PROGRAMM I
	double pitch;
	double aHorz = requiredHorizontalAccelerationToBase;
	double aVert = getRequiredVerticalAccelerationMain(inteceptAlt);
	setPitchAndEngineLevelForAccelerations(aHorz, aVert, used_thgroup, pitch, engineLevel);
	ypr_setpoint.y = pitch;
	if (engineLevel > getEngineLevelForIgnition()) setProgram(610);
}
void autopilot::program655()	//Wait for acceleration (No braking) RCS and RADAR (Retro Engine Program)
{
	program700(); //YAW PROGRAMM
	program715(); //BANK PROGRAMM I
	double pitch;
	double aHorz = requiredHorizontalAccelerationToBase;
	double aVert = getRequiredVerticalAccelerationMain(inteceptAlt);
	setPitchAndEngineLevelForAccelerations(aHorz, aVert, used_thgroup, pitch, engineLevel);
	ypr_setpoint.y = pitch;
	if (engineLevel > getEngineLevelForIgnition()) setProgram(660);
}
// NEW TO TEST
void autopilot::program410()	//Decent and brake (Hover Engine Mode)
{
	program300(); //YAW PROGRAMM
	program310(); //BANK PROGRAMM I
	double pitch;
	double aHorz = requiredHorizontalAccelerationToInterceptPoint;
	
	double aVert = getRequiredVerticalAcceleration(inteceptAlt);
	//double aVert2 = getRequiredVerticalAccelerationBase(inteceptAlt); // NEW TO TEST
	
	setPitchAndEngineLevelForAccelerations(aHorz, aVert, used_thgroup, pitch, engineLevel);
	if (vaChannel) v->SetThrusterGroupLevel(used_thgroup, engineLevel);
	ypr_setpoint.y = pitch;
	if (requiredHorizontalAccelerationToInterceptPoint < requiredHorizontalAccelerationToBase * preHold || engineLevel == 0) setProgram(420);
}

void autopilot::program610()	//Decent and brake (Main Engine Mode)
{
	program700(); //YAW PROGRAMM
	program710(); //BANK PROGRAMM I
	double pitch;
	double aHorz = requiredHorizontalAccelerationToBase;
	double aVert = getRequiredVerticalAccelerationMain(inteceptAlt);
	setPitchAndEngineLevelForAccelerations(aHorz, aVert, used_thgroup, pitch, engineLevel);		

	VECTOR3 v3;
	v->GetGroundspeedVector(REFFRAME::FRAME_LOCAL, v3);

	//if (oapiGetFocusInterface() == v) sprintf(oapiDebugString(), "%f", v3.z);
	if (vaChannel)	
	{
		if (engineLevel > 0)
			v->SetThrusterGroupLevel(used_thgroup, engineLevel);
		else if (v3.z > 0)
			v->SetThrusterGroupLevel(used_thgroup, 0);
	}
	if (/*HorizontalSpeed < 0.5 ||*/ !closingBase ||v3.z >= 0)
	{
		yawFinal = v->GetYaw();
		setProgram(540);
	}
	ypr_setpoint.y = pitch;	
	if (vaChannel)
		v->SetThrusterGroupLevel(THGROUP_HOVER, getSaveAlt(v, 40 - (v->GetAltitude(AltitudeMode::ALTMODE_MEANRAD) - baseElevation) )); //Emergency Hove Ignition if crash is imminent
}

void autopilot::program660()	//Decent and brake (Retro Engine Mode)
{
	program700(); //YAW PROGRAMM
	program715(); //BANK PROGRAMM Retro Engine
	double pitch;
	double aHorz = requiredHorizontalAccelerationToBase;
	double aVert = getRequiredVerticalAccelerationMain(inteceptAlt);
	setPitchAndEngineLevelForAccelerations(aHorz, aVert, used_thgroup, pitch, engineLevel);
	if (vaChannel) v->SetThrusterGroupLevel(used_thgroup, engineLevel);
	if (HorizontalSpeed < 0.5)
	{
		yawFinal = v->GetYaw();
		setProgram(540);
	}
	ypr_setpoint.y = pitch;
}

void autopilot::program420()	// Rotate to near horizontal attitude (Hover Engine Mode)
{
	double pitch;
	double aHorz = requiredHorizontalAccelerationToBase + 0.05; //Additional horizontal acceleration
	double aVert = getRequiredVerticalAcceleration(inteceptAlt);

	setPitchAndEngineLevelForAccelerations(aHorz * preHold, aVert, THGROUP_HOVER, pitch, engineLevel);
	if (pitch < 1.5) program320(); //Bank Program II
	else program330(); //BANK PROGRAMM III

	if (vaChannel) v->SetThrusterGroupLevel(THGROUP_HOVER, engineLevel);
	ypr_setpoint.y = pitch;

	// Provisorische Notfallumschaltung auf Endlandeprogramm bei zu flachem Anflugwinkel -----
	if (HorizontalSpeed < 1.0)
	{
		yawFinal = v->GetYaw();
		ptrProgram = 540;
	}
}

void autopilot::program300()	//YAW PROGRAMM HOVER
{
	ypr_setpoint.x = horizontalSpeedVectorHeading;
}

void autopilot::program700()	//YAW PROGRAMM MAIN Engine
{
	double dirAbs = MYMATH::getDirAbs(v, targetPoint.y, targetPoint.x);
	double dirVector = ORBITERTOOLS::getFlightVectorHeading(v);
	double delta = dirAbs - dirVector;
	ypr_setpoint.x = dirVector - (delta * 4);
}

void autopilot::program310()	//BANK PROGRAMM I  HOVER
{
	double dirAbs = MYMATH::getDirAbs(v, targetPoint.y, targetPoint.x);
	double dirVector = ORBITERTOOLS::getFlightVectorHeading(v);
	double delta = dirAbs - dirVector;
	ypr_setpoint.z = (delta) * 4;
}

void autopilot::program710()	//ROLL PROGRAMM I  MAIN Engine
{
	ypr_setpoint.z = PI;
}

void autopilot::program715()	//ROLL PROGRAMM I  RETRO Engine
{
	ypr_setpoint.z = 0;
}

void autopilot::program320()	//BANK PROGRAMM II  HOVER
{
	double dirAbs = MYMATH::getDirAbs(v, targetPoint.y, targetPoint.x);
	double dirVector = ORBITERTOOLS::getFlightVectorHeading(v);
	double delta = dirAbs - dirVector;
	ypr_setpoint.z = delta * 0.5;
}

void autopilot::program330()	//BANK PROGRAMM III: Keine �nderung der Rotation um die Achse welche die horizontale Schubrichtung vorgibt mehr.
{
	ypr_setpoint.z = 0;
}

void autopilot::program540()	//Hover over pad and land (Hover Engine Mode+?)
{
	if (HorizontalSpeed < 0.1) v->SetThrusterGroupLevel(used_thgroup, 0);

	//Heading
	VECTOR3 vspeed;
	v->GetAirspeedVector(FRAME_LOCAL, vspeed);
	double f_v = 0.075;
	double f_a = 0.15;
	//double heading;
	ypr_setpoint.x = yawFinal;

	//Pitch	
	double vSetZ = (deltaPos.z * f_v);
	if (vSetZ > 10) vSetZ = 10;
	if (vSetZ < -10) vSetZ = -10;
	double aSetZ = ((vSetZ - vspeed.z) * f_a);
	if (aSetZ > 1) aSetZ = 1;
	if (aSetZ < -1) aSetZ = -1;
	double pitch = 0;
	setPitchAndEngineLevelForAccelerations(aSetZ, 0, THGROUP_HOVER, pitch, engineLevel);
	if (pitch > 0.25) pitch = 0.25;
	if (pitch < -0.25) pitch = -0.25;
	ypr_setpoint.y = pitch;

	//Roll
	double vSetX = (deltaPos.x) * f_v;
	if (vSetX > 10) vSetX = 10;
	if (vSetX < -10) vSetX = -10;
	double aSetX = -((vSetX - vspeed.x) * f_a);
	if (aSetX > 1) aSetX = 1;
	if (aSetX < -1) aSetX = -1;
	double roll = 0;
	setPitchAndEngineLevelForAccelerations(aSetX, 0, THGROUP_HOVER, roll, engineLevel);
	if (roll > 0.25) roll = 0.25;
	if (roll < -0.25) roll = -0.25;
	ypr_setpoint.z = roll;

	//Vertical speed (Hover)
	//double v_set = -(altOverGround / 20) - 0.1;
	double v_set = -((altOverGround-(HorizontalSpeed * 5 + distanceToBasePad * 5)) / 20) - 0.1;
	double av = getAccelerationForVerticalSpeed(v, v_set) - 0.05;
	if (v->GetAltitude(AltitudeMode::ALTMODE_GROUND) > 40.5)
		engineLevel = getSaveAlt(v, 40);
	else engineLevel = getThrustForVerticalAcceleration(av, THGROUP_HOVER);
	if (vaChannel) v->SetThrusterGroupLevel(THGROUP_HOVER, engineLevel);
	double linFac = 50;
	v->SetThrusterGroupLevel(THGROUP_ATT_RIGHT, -aSetX * linFac);
	v->SetThrusterGroupLevel(THGROUP_ATT_LEFT, aSetX * linFac);
	v->SetThrusterGroupLevel(THGROUP_ATT_FORWARD, aSetZ * linFac);
	v->SetThrusterGroupLevel(THGROUP_ATT_BACK, -aSetZ * linFac);
}

double autopilot::getEngineLevelForIgnition()
{
	const double aMoonGround = 1.62;  // 1.125; //TODO!!!
	const double aMoonGroundHalf = aMoonGround / 2;
	const double aEngine = getMaxTotalThrGroupAcceleration(used_thgroup);
	const double restEngine = aEngine - aMoonGroundHalf;
	return restEngine / aEngine;
}

VECTOR3 autopilot::getYPRSpeedSetpointsByDeltaPhy3(VECTOR3 deltaPhy)
{	
	//TODO: VARIABKEB BEI ZEITBESCHLEUNIGUNG TESTEN
	VECTOR3 setPointSpeed = (dvOld - ypr_setpoint);
	VECTOR3 vMaxAccAcceleration = ORBITERTOOLS::GetMaxAngAcc(v);  //Returns the maximum angular acceleration (Omega)
	
	double maxPitchAcceleration = vMaxAccAcceleration.x;
	double maxYawAcceleration = vMaxAccAcceleration.y;	
	double maxBankAcceleration = vMaxAccAcceleration.z;

	VECTOR3 i;
	i.x = deltaPhy.x < 0 ? -1 : 1;
	i.y = deltaPhy.y < 0 ? -1 : 1;
	i.z = deltaPhy.z < 0 ? -1 : 1;

	VECTOR3 angularSpeedSetPoint1;
	VECTOR3 angularSpeedSetPoint2;
	VECTOR3 angularSpeedSetPoint;

    VECTOR3 sub = { 0.001, 0.001, 0.001 };

	angularSpeedSetPoint1.x = sqrt((abs(deltaPhy.x)) * 2 * maxPitchAcceleration) - sub.x;
	angularSpeedSetPoint1.y = sqrt((abs(deltaPhy.y)) * 2 * maxYawAcceleration) + sub.y;
	angularSpeedSetPoint1.z = sqrt((abs(deltaPhy.z)) * 2 * maxBankAcceleration) - sub.z;

	angularSpeedSetPoint2.x = sqrt((abs(deltaPhy.x * deltaPhy.x * 10)));
	angularSpeedSetPoint2.y = sqrt((abs(deltaPhy.y * deltaPhy.y * 10)));
	angularSpeedSetPoint2.z = sqrt((abs(deltaPhy.z * deltaPhy.z * 10)));
	
	angularSpeedSetPoint.x = min(angularSpeedSetPoint1.x, angularSpeedSetPoint2.x);
	angularSpeedSetPoint.y = min(angularSpeedSetPoint1.y, angularSpeedSetPoint2.y) ;
	angularSpeedSetPoint.z = min(angularSpeedSetPoint1.z, angularSpeedSetPoint2.z);

	double f = 0.85;
	
	angularSpeedSetPoint.x = (angularSpeedSetPoint.x + setPointSpeed.y) * i.x * f;
	angularSpeedSetPoint.y = (angularSpeedSetPoint.y + setPointSpeed.x) * i.y * f;
	angularSpeedSetPoint.z = (angularSpeedSetPoint.z + setPointSpeed.z) * i.z * f;

	dvOld = ypr_setpoint;
	return angularSpeedSetPoint;
}

void autopilot::ctrlYPR()
{	
	{ 
		// Classic method
		quaternion q_setpoints;
		q_setpoints.yprToQuat(ypr_setpoint);
		mq = q_setpoints.getMatrix();
		v_matrix = ORBITERTOOLS::getLocalRotationMatrix2(v);
		dm = mul(mq, MYMATH::invertMatrix(v_matrix));

		dv.x = -atan2(-dm.m23, dm.m22);
		dv.y = asin(dm.m21);
		dv.z = atan2(-dm.m31, dm.m11);

		currentYPR.x = v->GetPitch();
		currentYPR.y = v->GetYaw();
		currentYPR.z = v->GetBank();
	}

	bool td = ORBITERTOOLS::checkForTouchDown(v);
	if (td)
	{
		double currentTime = oapiGetSimTime();
		if (masterChannel)
		{
			touchDownTime = currentTime;
		}
		double delta = currentTime - touchDownTime;

		if (delta < 1.0)
		{
			resetThruster();
			v->SetWheelbrakeLevel(1);
		}
		masterChannel = false;
		yawChannel = false;
		pitchChannel = false;
		rollChannel = false;
		vaChannel = false;	
	}

	if (masterChannel_last && ! masterChannel)
	{		
		resetThruster();	
	}

	if (masterChannel) // If Autopilot is active...
	{			
		VECTOR3 yprSpeedSetPoint = getYPRSpeedSetpointsByDeltaPhy3(dv);	 // Getting the delta between current values and setpoints
		// The "if" also calls the method setYPRSpeed. It should return false on a NAN exception.
		if (!setYPRSpeed(yprSpeedSetPoint, yawChannel, pitchChannel, rollChannel) || currentYPR.x > PI2 ||currentYPR.y > PI2 || currentYPR.z > PI2 || ypr_setpoint.x > PI2 || ypr_setpoint.y > PI2 || ypr_setpoint.z > PI2 || currentYPR.x < -PI2 ||currentYPR.y < -PI2 || currentYPR.z < -PI2 || ypr_setpoint.x < -PI2 || ypr_setpoint.y < -PI2 || ypr_setpoint.z < -PI2)
		{
			currentYPR.x = 0;
			currentYPR.y = 0;
			currentYPR.z = 0;

			ypr_setpoint.x = 0;
			ypr_setpoint.y = 0;
			ypr_setpoint.z = 0;

			dv.x = 0;
			dv.y = 0;
			dv.z = 0;
		}
		thrusterResetet = false;		
	}
	masterChannel_last = masterChannel;
}

void autopilot::maincontroll()
{
	updateData();

	if (!masterChannel) return;
	if (masterChannel)
	{
		switch (ptrProgram)
		{
			case 400: program400();  break;
			case 405: program405(); getMaxElevationAngleToBase(); ctrlYPR(); break;
			case 410: program410(); getMaxElevationAngleToBase(); ctrlYPR(); break;
			case 420: program420(); ctrlYPR(); break;
			case 540: program540(); ctrlYPR(); break;
			case 600: program600();  break;
			case 605: program605(); getMaxElevationAngleToBase(); ctrlYPR(); break;
			case 610: program610(); getMaxElevationAngleToBase(); ctrlYPR(); break;
			case 650: program650();  break;
			case 655: program655();  getMaxElevationAngleToBase(); ctrlYPR(); break;
			case 660: program660();  getMaxElevationAngleToBase(); ctrlYPR(); break;			
		}
	}
}

void autopilot::resetThruster()
{
	for (unsigned i = 0; i < v->GetThrusterCount(); i++)
	{
		THRUSTER_HANDLE th = v->GetThrusterHandleByIndex(i);
		v->SetThrusterLevel(th,0);
		v->SetThrusterLevel(th, 0);

		v->SetThrusterGroupLevel(THGROUP_ATT_YAWLEFT, 0);
		v->SetThrusterGroupLevel(THGROUP_ATT_YAWRIGHT, 0);
		v->SetThrusterGroupLevel(THGROUP_ATT_PITCHDOWN, 0);
		v->SetThrusterGroupLevel(THGROUP_ATT_PITCHUP, 0);
		v->SetThrusterGroupLevel(THGROUP_ATT_BANKRIGHT, 0);
		v->SetThrusterGroupLevel(THGROUP_ATT_BANKLEFT, 0);

		v->SetThrusterGroupLevel(THGROUP_ATT_FORWARD, 0);
		v->SetThrusterGroupLevel(THGROUP_ATT_BACK, 0);
		v->SetThrusterGroupLevel(THGROUP_ATT_LEFT, 0);
		v->SetThrusterGroupLevel(THGROUP_ATT_RIGHT, 0);
	}
	thrusterResetet = true;	
}

void autopilot::getMaxElevationAngleToBase()
{	
	double end = terrainScanPtr + rangePerScan;
	double vesselAlt = v->GetAltitude(AltitudeMode::ALTMODE_MEANRAD);
	double elevationAngleFromVessel = 0;
	for (double d = terrainScanPtr; d <= end; d += scanResolution)
	{
		if (d > distanceToBasePad) break;
		double pointElevation = ORBITERTOOLS::getElevationAtDistance(v, d);
		terrainAltAtPtr = pointElevation;
		elevationAngleFromVessel = atan((vesselAlt - pointElevation) / d);		
		if (elevationAngleFromVessel < maxElevationAngleCurrentScan)
		{
			maxElevationAngleCurrentScan = elevationAngleFromVessel;
			distanceToMaxElevationFromBaseCurrentScan = distanceToBasePad - d;						
			maxElevationCurrentScan = pointElevation;		
		}
	}	
	terrainScanPtr = end;
	
	if (terrainScanPtr > distanceToBasePad)
	{
		terrainScanPtr = 0;
		distanceToMaxElevationFromBase = distanceToMaxElevationFromBaseCurrentScan;
		maxElevationAngleCurrentScan = PI2;
		maxElevation = maxElevationCurrentScan;
	}	

	double baseAngleFromVessel         = atan((vesselAlt - baseElevation) / distanceToBasePad);	
	double maxElevationAngleFromVessel = atan((vesselAlt - maxElevation ) / distanceToMaxElevation);

	if (maxElevationAngleFromVessel > baseAngleFromVessel || distanceToMaxElevationFromBase < 50)
	{
		maxElevation = baseElevation;
		distanceToMaxElevation = distanceToBasePad;
		distanceToMaxElevationFromBase = 0;
	}
	//sprintf(oapiDebugString(), "%f   >    %f", maxElevationAngleFromVessel toDeg, baseAngleFromVessel toDeg);
}

double autopilot::getGearAlt(VESSEL* vessel)
{
	VECTOR3 tpl[3], tpg[3];
	double lng, lat, rmin = DBL_MAX, rmax = DBL_MIN;
	vessel->GetTouchdownPoints(tpl[0], tpl[1], tpl[2]);
	for (int i = 0; i<3; i++)
	{
		double r = 0;
		oapiLocalToGlobal(vessel->GetHandle(), tpl + i, tpg + i);
		oapiGlobalToEqu(vessel->GetSurfaceRef(), tpg[i], &lng, &lat, &r);
		r = r - oapiGetSize(vessel->GetSurfaceRef()) - v->GetAltitude();
		if (r>rmax) rmax = r;
		if (r<rmin) rmin = r;
	}
	return rmin;
}

//double autopilot::getAltitudeAtDistance(double distance)
//{
//	double heading_v = ORBITERTOOLS::getFlightVectorHeading(v);
//	double deltaSBase = 0;
//	dt_maxElevation = getDtForDistance(distance);
//	double latAtDistance, lonAtDistance;
//	ORBITERTOOLS::pointRadialDistance(v, distance, &latAtDistance, &lonAtDistance);
//	const VECTOR3 v3_base = oapiGetGroundVector(v->GetGravityRef(), lonAtDistance, latAtDistance);
//	const double v_base = length(v3_base);
//	double s_base = v_base * dt_maxElevation * cos(heading_v + PI05);
//	double dtForS_base = getDtForDistance(fabs(s_base));
//	dt_maxElevation = s_base < 0 ? dt_maxElevation + dtForS_base : dt_maxElevation - dtForS_base;
//	s_base = v_base * dtForS_base * cos(heading_v + PI05);
//	dtForS_base = getDtForDistance(fabs(s_base));
//	dt_maxElevation = s_base < 0 ? dt_maxElevation + dtForS_base : dt_maxElevation - dtForS_base;
//	double altAtDt = getAltitudeAtDt(dt_maxElevation);
//	double dBaseAlt = altAtDt - ORBITERTOOLS::getElevationAtDistance(v, distance);	
//	return dBaseAlt;
//}

double autopilot::getAltitudeAtDistance(double distance)
{
	double heading_v = ORBITERTOOLS::getFlightVectorHeading(v);
	double deltaSBase = 0;
	dt_maxElevation = getDtForDistance(distance);
	double latAtDistance, lonAtDistance;
	ORBITERTOOLS::pointRadialDistance(v, distance, &latAtDistance, &lonAtDistance);
	const VECTOR3 v3_base = oapiGetGroundVector(v->GetGravityRef(), lonAtDistance, latAtDistance);
	const double v_base = length(v3_base);
	
	double s_base = v_base * dt_maxElevation * cos(heading_v + PI05);
	double dtForS_base = getDtForDistance(fabs(s_base));
	

	dt_maxElevation = s_base < 0 ? dt_maxElevation + dtForS_base : dt_maxElevation - dtForS_base;
	s_base = v_base * dtForS_base * cos(heading_v + PI05);
	dtForS_base = getDtForDistance(fabs(s_base));



	dt_maxElevation = s_base < 0 ? dt_maxElevation + dtForS_base : dt_maxElevation - dtForS_base;
	s_base = v_base * dtForS_base * cos(heading_v + PI05);
	dtForS_base = getDtForDistance(fabs(s_base));
	

	dt_maxElevation = s_base < 0 ? dt_maxElevation + dtForS_base : dt_maxElevation - dtForS_base;
	double altAtDt = getAltitudeAtDt(dt_maxElevation);	
	double r = oapiGetSize(v->GetGravityRef());
	


	//https://de.wikipedia.org/wiki/Kreissegment
	//altAtDt += r - 0.5 * sqrt(4 * r*r - fabs(s_base * s_base));

	

	double dBaseAlt = altAtDt - ORBITERTOOLS::getElevationAtDistance(v, distance);	
	//sprintf(oapiDebugString(), "%f - %f = %f", altAtDt, ORBITERTOOLS::getElevationAtDistance(v, distance), dBaseAlt);
	return dBaseAlt;
}

double autopilot::getDtForDistance(double distance)
{
	OBJHANDLE hRef = v->GetGravityRef();
	ORBITPARAM *prm = new ORBITPARAM;
	ELEMENTS el;
	v->GetElements(hRef, el, prm);
	double s = oapiGetSize(hRef); //1.737,4 km
	double angle = distance / oapiGetSize(hRef);
	double eca = ORBITERTOOLS::tra2eca(posangle(prm->TrA + angle), el.e);
	const double mnm = sqrt(oapiGetMass(hRef) * GGRAV / fabs(el.a * el.a * el.a));
	const double dm1 = posangle(ORBITERTOOLS::eca2mna(eca, el.e) - prm->MnA);
	double dt1 = dm1 / mnm;
	return dt1; // Travel time for "angle" less than one orbit
}

double autopilot::getAltitudeAtDt(double dt)
{
	ORBITPARAM *prm = new ORBITPARAM;
	ELEMENTS el;
	OBJHANDLE hRef = v->GetGravityRef();
	v->GetElements(hRef, el, prm);
	const double mna = prm->MnA + PI2 * dt / prm->T;
	const double eca = ORBITERTOOLS::mna2eca(posangle(mna), el.e);
	return el.a * (1.0 - el.e*cos(eca)) - oapiGetSize(hRef);
}
