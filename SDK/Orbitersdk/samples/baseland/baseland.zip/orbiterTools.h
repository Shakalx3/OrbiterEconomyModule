#ifndef ORBITERTOOLS_H
#define ORBITERTOOLS_H

#include "includes.h"


class ORBITERTOOLS
{
	public:
		
		//Normaly the right one...
		static MATRIX3 getLocalRotationMatrix(VESSEL* v)
		{
			OBJHANDLE hVessel = v->GetHandle();
			OBJHANDLE hMoon;// = oapiGetObjectByName("Moon");
			hMoon = v->GetGravityRef();
			MATRIX3 m3Vessel = getRotationMatrixFromHandle(hVessel);
			MATRIX3 m3Moon  = getRotationMatrixFromHandle(hMoon);
			MATRIX3 m3rel = mul(MYMATH::invertMatrix(m3Vessel), m3Moon);
			double ln,lt,r;
			oapiGetEquPos(hVessel,&ln,&lt,&r);	
			VECTOR3 ve = {0,1,0};
			m3rel = MYMATH::rotateMatrix(ve, m3rel, -ln);
			ve.x = 0;	ve.y = 0;	ve.z = 1;
			m3rel = MYMATH::rotateMatrix(ve, m3rel, lt);
			return m3rel;
		}

		//Works corect for autopilot.cpp
		static MATRIX3 getLocalRotationMatrix2(VESSEL* v)
		{
			OBJHANDLE hVessel = v->GetHandle();
			OBJHANDLE hMoon;// = oapiGetObjectByName("Moon");
			hMoon = v->GetGravityRef();
			MATRIX3 m3Vessel = getRotationMatrixFromHandle(hVessel);
			MATRIX3 m3Moon  = getRotationMatrixFromHandle(hMoon);
			VECTOR3 ve;
			ve.x = 0;	ve.y = 0;	ve.z = -1;
			
			m3Vessel = MYMATH::rotateMatrix(ve,m3Vessel,PI);
			ve.x = -1;	ve.y = 0;	ve.z = 0;
			m3Vessel = MYMATH::rotateMatrix(ve,m3Vessel,-PI05);
			MATRIX3 m3rel = mul(MYMATH::invertMatrix(m3Vessel), m3Moon);
			double ln,lt,r;
			oapiGetEquPos(hVessel,&ln,&lt,&r);	
			ve.x = 0;	ve.y = 1; ve.z = 0;
			m3rel = MYMATH::rotateMatrix(ve, m3rel, -ln);
			ve.x = 0;	ve.y = 0;	ve.z = 1;
			m3rel = MYMATH::rotateMatrix(ve, m3rel, lt);
			return m3rel;
		}
				
		static VECTOR3 getThrGroupDir(VESSEL *v,THGROUP_TYPE thgt)
		{
			VECTOR3 dirTotal = {0,0,0};
			for(unsigned int i=0; i<v->GetGroupThrusterCount(thgt); i++) 
			{						
				THRUSTER_HANDLE th=v->GetGroupThruster(thgt,i);			
				VECTOR3 dir;
				v->GetThrusterDir(th,dir);
				dirTotal = dirTotal + dir;
			}
			dirTotal = dirTotal / v->GetGroupThrusterCount(thgt);
			return dirTotal;			
		}


		static double GetMaxTorqueFromTHGroup( VESSEL * v, THGROUP_TYPE thGroupType)
		{
			double torqueSum = 0;
			for (unsigned i = 0; i < v->GetGroupThrusterCount(thGroupType); ++i) 
			{
				THRUSTER_HANDLE th = v->GetGroupThruster(thGroupType, i);
				VECTOR3 thPos;
				v->GetThrusterRef(th, thPos);
				double torque = v->GetThrusterMax(th) * length(thPos);
				torqueSum += torque;
			}
			return torqueSum;
		}

		static VECTOR3 GetMaxAngAcc(VESSEL * v )
		{
			VECTOR3 pmi;
			v->GetPMI(pmi);
			double pitchTorque = GetMaxTorqueFromTHGroup( v, THGROUP_ATT_PITCHUP );
			double yawTorque = GetMaxTorqueFromTHGroup( v, THGROUP_ATT_YAWLEFT );
			double bankTorque = GetMaxTorqueFromTHGroup( v, THGROUP_ATT_BANKLEFT );
    
			double mass = v->GetMass();
			double pitchAcc = pitchTorque / (mass * pmi.x);
			double yawAcc = yawTorque / (mass * pmi.y);
			double bankAcc = bankTorque / (mass * pmi.z);
    
			VECTOR3 ret;
			ret.x = pitchAcc;
			ret.y = yawAcc;
			ret.z = bankAcc;

			return ret;
		}
		static MATRIX3 getRotationMatrixFromHandle(OBJHANDLE object)
		{
			MATRIX3 m;
			oapiGetRotationMatrix(object,&m);
			return m;
		}

		static double getEngineVectorForward(VESSEL *v,THGROUP_TYPE thgt)
		{			
			VECTOR3 edirLocal =  getThrGroupDir(v, thgt);
			VECTOR3 edirGlobal = {0,0,0};
			v->HorizonRot(edirLocal,edirGlobal);
			return -edirGlobal.z;
		}


		static double getEngineVectorDownward(VESSEL *v,THGROUP_TYPE thgt)
		{
			
			VECTOR3 edirLocal =  getThrGroupDir(v, thgt);
			VECTOR3 edirGlobal = {0,0,0};
			v->HorizonRot(edirLocal,edirGlobal);
			return -edirGlobal.y;
		}
		
		static double getFlightVectorHeading(VESSEL *v)
		{			
			VECTOR3 shipAirspeedVector;
			v->GetHorizonAirspeedVector(shipAirspeedVector);
			double vector = atan2(shipAirspeedVector.x, shipAirspeedVector.z);
			return vector;
		}

		static double getEngineHeading(VESSEL *v, THGROUP_TYPE thGroupType)
		{
			VECTOR3 engineDir = getThrGroupDir(v, thGroupType);
			VECTOR3 horzDir;
			v->HorizonRot(engineDir,horzDir);
			horzDir.x = -horzDir.x;
			horzDir.z = -horzDir.z;
			horzDir.y = 0;
			normalise(horzDir);
			return atan2(horzDir.x, horzDir.z);
		}

		/*
			ISSUE: WORKS FOR HOVER ENGINE ONLY WITHOUT GIMBAL!
		*/
		static double getMaxHorizontalAcceleration(VESSEL *v, THGROUP_TYPE thGroupType, double bank, double level=1)
		{
			double maxThrust = 0;
			int count = v->GetGroupThrusterCount(thGroupType);
			for (int i = 0; i < count; i++)
			{
				THRUSTER_HANDLE th = v->GetGroupThruster(thGroupType,i);
				maxThrust += v->GetThrusterMax(th);
			}
			double maxa = (level*maxThrust) / v->GetMass();
			double engineAngle = getEngineHeading(v,thGroupType );			
			maxa = maxa * cos(bank);			
			return maxa ;
		}

		static double getPitchForHorizontalAcceleration(VESSEL *v, THGROUP_TYPE thGroupType, double bank, double setPoint, double level=0)
		{
			if (level == 0) level = v->GetThrusterGroupLevel(thGroupType);
			double maxa = getMaxHorizontalAcceleration(v,thGroupType,bank,level);						
			if (abs(maxa) ==0) return PI05;
			if (abs(setPoint) / abs(maxa) >= 1) return PI05;
			if (abs(setPoint) / abs(maxa) <= 0) return PI05;
			double r = acos((setPoint) / (maxa));	
			return r - PI05;
		}

		static bool checkForTouchDown(VESSEL *v)
		{
			VECTOR3 tp1,tp2,tp3; 
			int i = 12;
			int* ptrRes = &i;

			double Alt = v->GetAltitude(AltitudeMode::ALTMODE_GROUND, ptrRes);
			v->GetTouchdownPoints(tp1,tp2,tp3);
			const double ShutDownAlt = 0.25;
			Alt = Alt - ShutDownAlt;
			double td1 = Alt-fabs(tp1.y);
			double td2 = Alt-fabs(tp2.y);
			double td3 = Alt-fabs(tp3.y);
			if (td1 <= 0 || td2 <= 0 || td3 <= 0)
			{
				/*
				//if (*ptrRes == 10)
				if (*ptrRes == 12)
				{
					sprintf(oapiDebugString(), "%i", *ptrRes);
					return true;
				}
				*/
				return true;
			}
			return false;
		}

		static bool checkForTouchDown2(VESSEL *v)
		{
			VECTOR3 tp1, tp2, tp3;
			double Alt = v->GetAltitude(AltitudeMode::ALTMODE_GROUND);
			v->GetTouchdownPoints(tp1, tp2, tp3);
			const double ShutDownAlt = 0.001;
			Alt = Alt - ShutDownAlt;
			double td1 = Alt - fabs(tp1.y);
			double td2 = Alt - fabs(tp2.y);
			double td3 = Alt - fabs(tp3.y);
			if (td1 <= 0 || td2 <= 0 || td3 <= 0) return true;
			return false;
		}

		static void pointRadialDistance(double lat1, double lon1, double bearing, double distance, OBJHANDLE gRef, double *lat2, double *lon2)
		{
			double rdistance = distance / oapiGetSize(gRef);
			*lat2 = asin(sin(lat1) * cos(rdistance) + cos(lat1) * sin(rdistance) * cos(bearing));
			*lon2 = lon1 + atan2(sin(bearing) * sin(rdistance) * cos(lat1), cos(rdistance) - sin(lat1) * sin(*lat2));

			/*
			Long:
			-180 bis + 180
			- PI bis + PI
			Lat :
			-90 bis + 90
			- PI / 2 bis + PI / 2
			*/
			if (*lon2 >  PI) *lon2 -= 2 * PI;
			if (*lon2 < -PI) *lon2 += 2 * PI;

			if (*lat2 >  PI / 2) *lat2 -= PI;
			if (*lat2 < -PI / 2) *lat2 += PI;
		}

		static void pointRadialDistance(VESSEL * v, double distance, double *lat, double *lon)
		{
			VECTOR3 shipAirspeedVector;
			v->GetHorizonAirspeedVector(shipAirspeedVector);
			double heading = atan2(shipAirspeedVector.x, shipAirspeedVector.z);
						
			double lon2, lat2, rad;
			v->GetEquPos(lon2, lat2, rad);
			pointRadialDistance(lat2, lon2, heading, distance, v->GetGravityRef(), lat, lon);
		}

		static void pointRadialDistance(double lat1, double lon1, double bearing, double distance, VESSEL * v, double *lat2, double *lon2)
		{
			pointRadialDistance(lat1, lon1, bearing, distance, v->GetGravityRef(), lat2, lon2);
		}

		static double getElevationAtDistance(double lng, double lat, double heading, double distance, OBJHANDLE gRef)
		{
			double lng2, lat2;
			if (heading != heading) return 0;
			pointRadialDistance(lat, lng, heading, distance, gRef, &lat2, &lng2);
			if (lat2 != lat2) return 0;
			if (lng2 != lng2) return 0;
			double elevation = oapiSurfaceElevation(gRef, lng2, lat2);
			return elevation;
		}

		static double getElevationAtDistance(VESSEL* v, double distance)
		{
			double lng, lat, rad;
			v->GetEquPos(lng,lat,rad);
			double heading = 0;
			VECTOR3 shipAirspeedVector;
			v->GetHorizonAirspeedVector(shipAirspeedVector);
			heading = atan2(shipAirspeedVector.x, shipAirspeedVector.z);
			if (heading != heading) return 0;
			return getElevationAtDistance(lng, lat, heading, distance, v->GetGravityRef());
		}
/*
		static double getElevationAtDistance(VESSEL* v, double distanceX, double distanceZ)
		{			
			double lng, lat, rad;
			v->GetEquPos(lng,lat,rad);
			double lng2, lat2;	
			double lng3, lat3;	
			double heading = 0;
			heading = ORBITERTOOLS::getFlightVectorHeading(v);		
			pointRadialDistance(lat,lng,heading,distanceZ,v,&lat2,&lng2);
			pointRadialDistance(lat2,lng2,heading+90,distanceX,v,&lat3,&lng3);
			if (lat3 != lat3) return 0;
			if (lng3 != lng3) return 0;

			if (oapiIsVessel(v->GetHandle()))
			{
				OBJHANDLE gbHandle = v->GetGravityRef();
				return oapiSurfaceElevation(v->GetGravityRef(), lng3, lat3);
			}
			else return 0;
		}
		*/
		static VECTOR3 studVectorOrg(VECTOR3 v3, const double deadBand)
		{
			if (v3.x > 0)
			{
				v3.x -= deadBand;
				if (v3.x < 0) v3.x = 0;
			}
			else
			{
				v3.x += deadBand;
				if (v3.x > 0) v3.x = 0;
			}
			if (v3.y > 0)
			{
				v3.y -= deadBand;
				if (v3.y < 0) v3.y = 0;
			}
			else
			{
				v3.y += deadBand;
				if (v3.y > 0) v3.y = 0;
			}
			if (v3.z > 0)
			{
				v3.z -= deadBand;
				if (v3.z < 0) v3.z = 0;
			}
			else
			{
				v3.z += deadBand;
				if (v3.z > 0) v3.z = 0;
			}
			return v3;
		}

		static VECTOR3 studVector(VECTOR3 v3, const double deadBand, double const reduceFactor)
		{
			if (v3.x > 0)
			{
				if (v3.x - deadBand < 0) v3.x *= reduceFactor;
			}
			else
			{
				if (v3.x + deadBand > 0) v3.x *= reduceFactor;
			}
			if (v3.y > 0)
			{
				if (v3.y - deadBand < 0) v3.y *= reduceFactor;
			}
			else
			{
				if (v3.y + deadBand > 0) v3.y *= reduceFactor;
			}
			if (v3.z > 0)
			{
				if (v3.z - deadBand < 0) v3.z *= reduceFactor;
			}
			else
			{
				if (v3.z + deadBand > 0) v3.z *= reduceFactor;
			}
			return v3;

		}

		static VECTOR3 studVector2(VECTOR3 v3, const double deadBand)
		{
			if (v3.x > 0)
			{
				v3.x -= deadBand;
				if (v3.x < deadBand) v3.x *= v3.x;
			}
			else
			{
				v3.x += deadBand;
				if (v3.x > deadBand) v3.x *= v3.x;
			}


			if (v3.y > 0)
			{
				v3.y -= deadBand;
				if (v3.y < deadBand) v3.y *= v3.y;
			}
			else
			{
				v3.y += deadBand;
				if (v3.y > deadBand) v3.y *= v3.y;
			}
			if (v3.z > 0)
			{
				v3.z -= deadBand;
				if (v3.z < deadBand) v3.z *= v3.z;
			}
			else
			{
				v3.z += deadBand;
				if (v3.z > deadBand) v3.z *= v3.z;
			}
			return v3;
		}	



		static double mna2eca(double mna, double ecc)
		{
			// iterative calculation of eccentric anomaly from mean anomaly
			register double eca, m, x;
			int i;
			if (ecc<1.0) {
				eca = mna + ecc * sin(mna);
				m = mna - eca + ecc * sin(eca);
				for (i = 0; (fabs(m)>1e-14 && i<22); i++) {
					x = m / (1.0 - ecc * cos(eca));
					if (x>1.0) x = 1.0; else if (x<-1.0) x = -1.0;
					eca += x;
					m = mna - eca + ecc * sin(eca);
				}
				return eca;
			}
			else {
				eca = 0;
				m = mna - ecc * sinh(eca) + eca;
				for (i = 0; fabs(m)>1e-14 && i<22; i++) {
					x = m / (ecc * cosh(eca) - 1.0);
					if (x>1.0) x = 1.0; else if (x<-1.0) x = -1.0;
					eca += x;
					m = mna - ecc * sinh(eca) + eca;
				}
			}
			return eca;
		}


		static double tra2eca(double tra, double e)
		{
			double eca;
			double cos_tra = cos(tra);

			if (e>1.0) {
				eca = acosh((e + cos_tra) / (1.0 + e * cos_tra));
				if (tra>PI) eca = -eca;
				return(eca);
			}

			eca = acos((e + cos_tra) / (1.0 + e * cos_tra));
			if (tra>PI) eca = PI2 - eca;
			return(eca);
		}

		static double eca2mna(double eca, double ecc)
		{
			if (ecc<1.0) return eca - (ecc * sin(eca));
			return ((ecc * sinh(eca)) - eca);
		}



};

#endif